export const Config = {
  environment: process.env.STAGE ?? 'local',
  timezone: 'America/Santiago',
  payment: {
    subject: 'Simpply',
    currency: 'CLP'
  }
}
