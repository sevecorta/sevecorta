import { Config } from '@/core/config'
import { ILogger } from '@/core/ports/logger'
import { IPaymentGateway } from '@/core/ports/payment-gateway'
import { IUniqueID } from '@/core/ports/unique-id'
import { IAppointmentPersist } from '@/core/persist/appointment'
import { IAppointmentPaymentPersist } from '@/core/persist/appointment-payment'
import { inject, injectable } from 'tsyringe'

interface Request {
  appointmentId: string
  email: string
  urlConfirmation: string
  urlReturn: string
}

@injectable()
export class PaymentCreate {
  constructor (
    @inject('AppointmentPersist')
    private readonly appointmentPersist: IAppointmentPersist,

    @inject('AppointmentPaymentPersist')
    private readonly appointmentPaymentPersist: IAppointmentPaymentPersist,

    @inject('Logger')
    private readonly logger: ILogger,

    @inject('PaymentGateway')
    private readonly paymentGateway: IPaymentGateway,

    @inject('UniqueID')
    private readonly uniqueId: IUniqueID
  ) {}

  async execute (data: Request): Promise<string> {
    this.logger.debug('data', data)

    const appointment = await this.appointmentPersist.findById(
      data.appointmentId
    )

    const order = this.uniqueId.generate()
    const flowPaymentBody = {
      subject: Config.payment.subject,
      currency: Config.payment.currency,
      email: data.email,
      amount: appointment.amount,
      order: order,
      urlConfirmation: data.urlConfirmation,
      urlReturn: data.urlReturn
    }

    const paymentGateway = await this.paymentGateway.create(flowPaymentBody)

    this.logger.debug('paymentGateway', paymentGateway)

    const paymentId = await this.appointmentPaymentPersist.create({
      appointmentId: data.appointmentId,
      amount: appointment.amount,
      state: 'pending',
      order: order,
      paymentPayer: data.email,
      paymentToken: paymentGateway.token,
      paymentOrder: paymentGateway.order,
      paymentUrl: paymentGateway.url
    })

    return paymentId
  }
}
