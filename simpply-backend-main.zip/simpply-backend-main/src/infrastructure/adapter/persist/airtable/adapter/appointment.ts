import { ILogger } from '@/core/ports/logger'
import {
  IAppointmentCreateInput,
  IAppointmentPersist,
  IAppointmentDTO,
  IAppointmentGroupByDateDTO
} from '@/core/persist/appointment'
import { inject, injectable } from 'tsyringe'
import { AirtableClient } from '../client'
import {
  AppointmentCollectionResponse,
  AppointmentResponse
} from '../schema/appointment'
import { AirtableAppointmentGroupByDateCollectionSchema } from '../schema/appointment-group-by-date'

@injectable()
export class AirtableAppointmentAdapter implements IAppointmentPersist {
  constructor (
    @inject('Logger') private readonly logger: ILogger
  ) {}

  async findById (id: string): Promise<IAppointmentDTO> {
    try {
      this.logger.debug('findById id', id)

      const resp = await AirtableClient.get(`appointment/${id}`)

      this.logger.debug('resp', resp.data)
      const data = AppointmentResponse.parse(resp.data)

      return {
        id: data.id,
        date: data.fields.date,
        amount: data.fields.amount,
        serviceId: data.fields.service[0],
        organizationId: data.fields.organization[0],
        customerId: data.fields.customer[0],
        locationId: data.fields.location[0],
        periodId: data.fields.period[0],
        createdTime: data.createdTime
      }
    } catch (err) {
      this.logger.debug('findById error', err)
      throw err
    }
  }

  async groupByDate (organizationId: string, year: number, month: number): Promise<IAppointmentGroupByDateDTO[]> {
    const yearMonth = `${year}-${String(month).padStart(2, '0')}`
    const formula = `AND(FIND('${organizationId}', {organization__record_id}) > 0, {date__year_month} = '${yearMonth}')`
    const resp = await AirtableClient.get('appointment_group_by_date', {
      params: { view: 'backend', filterByFormula: formula }
    })

    const data = AirtableAppointmentGroupByDateCollectionSchema.parse(resp.data)

    return data.records.map((record) => ({
      date: record.fields.date,
      scheduleId: record.fields.schedule[0],
      periodId: record.fields.period[0],
      count: record.fields.appointment_count
    }))
  }

  async create (params: IAppointmentCreateInput): Promise<string> {
    const bodyAppointment = {
      records: [
        {
          fields: {
            organization: [params.organizationId],
            service: [params.serviceId],
            schedule: [params.scheduleId],
            period: [params.periodId],
            customer: [params.customerId],
            location: [params.locationId],
            date: params.date,
            amount: params.amount
          }
        }
      ]
    }

    const respAppointment = await AirtableClient.post('appointment', bodyAppointment)
    const data = AppointmentCollectionResponse.parse(respAppointment.data)

    const appointmentId = data.records[0].id

    const bodyAppointmentPatient = {
      records: params.patientsId.map((patientId) => ({
        fields: {
          appointment: [appointmentId],
          customer: [patientId]
        }
      }))
    }
    await AirtableClient.post('appointment_patient', bodyAppointmentPatient)

    return appointmentId
  }
}
