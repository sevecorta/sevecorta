import { container } from 'tsyringe'
import { mock, when, instance, verifyAll } from 'strong-mock'
import { AppointmentFindById } from '@/application/appointment/find-by-id'
import { IAppointmentPersist } from '@/core/persist/appointment'
import { MockAppointmentDTO } from '@test/mock/core/persist/dto'
import { IUniqueID } from '@/core/ports/unique-id'

test('Debe devolver cita por id', async () => {
  const uniqueid = container.resolve<IUniqueID>('UniqueID')

  const appointmentMock = MockAppointmentDTO({
    organizationId: uniqueid.generate(),
    serviceId: uniqueid.generate(),
    customerId: uniqueid.generate()
  })

  const appointmentPersist = mock<IAppointmentPersist>()
  when(appointmentPersist.findById(appointmentMock.id)).thenResolve(appointmentMock)

  const scope = container.createChildContainer()
  scope.registerInstance('AppointmentPersist', instance(appointmentPersist))

  const application = scope.resolve(AppointmentFindById)
  const item = await application.execute({ id: appointmentMock.id })

  expect(item.id).toEqual(appointmentMock.id)
  verifyAll()
})
