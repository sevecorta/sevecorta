
import { Request } from 'express'
import { Loader } from './loader'

export interface IContext {
  request: Request
  loader: Loader
}
