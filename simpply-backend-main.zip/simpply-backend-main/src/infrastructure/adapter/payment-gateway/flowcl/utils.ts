import cryptojs from 'crypto-js'

export const FlowclUtils = {
  sign (payload: Record<string, unknown>, secretkey: string): string {
    const toSign = Object.keys(payload)
      .sort((a, b) => a.localeCompare(b))
      .reduce((base, key) => {
        return `${base}${key}${String(payload[key])}`
      }, '')

    const sign = cryptojs.HmacSHA256(toSign, secretkey)
    return sign.toString()
  }
}
