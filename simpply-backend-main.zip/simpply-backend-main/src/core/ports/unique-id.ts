export interface IUniqueID {
  generate: () => string
}
