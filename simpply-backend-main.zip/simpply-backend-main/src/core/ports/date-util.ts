export type DateUtilUnitType =
  | 'second'
  | 'minute'
  | 'hour'
  | 'day'
  | 'month'
  | 'year'

export interface IDateUtilAction {
  valueOf: () => number
  format: (template?: string) => string
  toISOString: () => string
  startOf: (unit: DateUtilUnitType) => IDateUtilAction
  endOf: (unit: DateUtilUnitType) => IDateUtilAction
  tz: (timezone: string) => IDateUtilAction
  add: (value: number, unit: DateUtilUnitType) => IDateUtilAction
  clone: () => IDateUtilAction
  daysInMonth: () => number
  year: (() => number) & ((value: number) => IDateUtilAction)
  month: (() => number) & ((value: number) => IDateUtilAction)
  date: (() => number) & ((value: number) => IDateUtilAction)
  hour: (() => number) & ((value: number) => IDateUtilAction)
  minute: (() => number) & ((value: number) => IDateUtilAction)
  second: (() => number) & ((value: number) => IDateUtilAction)
  isoWeekday: (() => number) & ((value: number) => IDateUtilAction)
}

export interface IDateUtil {
  now: () => IDateUtilAction
  tz: (value: string, timezone: string) => IDateUtilAction
  parse: (value: string, format?: string) => IDateUtilAction
}
