import { ISchedulePersist, IScheduleDTO } from '@/core/persist/schedule'
import { AirtableClient } from '../client'
import { ScheduleCollectionResponse } from '../schema/schedule'

export class AirtableScheduleAdapter implements ISchedulePersist {
  async search (organizationId: string): Promise<IScheduleDTO[]> {
    const formula = `FIND('${organizationId}', {organization__record_id}) > 0`
    const resp = await AirtableClient.get('schedule', {
      params: { view: 'backend', filterByFormula: formula }
    })

    const data = ScheduleCollectionResponse.parse(resp.data)

    return data.records.map((obj) => ({
      id: obj.id,
      dateStart: obj.fields.date_start,
      dateEnd: obj.fields.date_end,
      periodId: obj.fields.period[0],
      day: obj.fields.day,
      slots: obj.fields.slots
    }))
  }
}
