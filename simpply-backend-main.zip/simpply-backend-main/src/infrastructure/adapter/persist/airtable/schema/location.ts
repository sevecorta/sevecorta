import { z } from 'zod'

export const LocationResponse = z.object({
  id: z.string(),
  fields: z.object({
    name: z.string(),
    amount: z.number()
  }),
  createdTime: z.string()
})

export const LocationCollectionResponse = z.object({
  records: z.array(LocationResponse)
})
