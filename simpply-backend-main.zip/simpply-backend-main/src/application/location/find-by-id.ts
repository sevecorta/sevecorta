import { ILocationPersist, ILocationDTO } from '@/core/persist/location'
import { inject, injectable } from 'tsyringe'

interface Request {
  id: string
}

@injectable()
export class LocationFindById {
  constructor (
    @inject('LocationPersist')
    private readonly persist: ILocationPersist
  ) {}

  async execute (data: Request): Promise<ILocationDTO> {
    const item = await this.persist.findById(data.id)
    return item
  }
}
