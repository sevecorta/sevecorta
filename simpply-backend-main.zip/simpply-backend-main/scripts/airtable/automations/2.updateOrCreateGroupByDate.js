function containLinkId(link, id) {
  if (link && link.length > 0) {
    for (const lk of link) {
      if (lk.id === id) {
        return true;
      }
    }
  }
  return false;
}

let inputConfig = input.config();
let item = JSON.parse(inputConfig.item);
let table = base.getTable("appointment_group_by_date");
let view = table.getView("backend");

console.log("item", item);

let queryResult = await view.selectRecordsAsync({
  fields: ["date", "organization", "schedule", "period", "appointment"],
  sorts: [{ field: "date", direction: "desc" }],
});

let itemToUpdate;
for (const record of queryResult.records) {
  if (record.getCellValue("date") !== item.date) {
    continue;
  }

  if (
    !containLinkId(record.getCellValue("organization"), item.organizationId)
  ) {
    continue;
  }

  if (!containLinkId(record.getCellValue("schedule"), item.scheduleId)) {
    continue;
  }

  if (!containLinkId(record.getCellValue("period"), item.periodId)) {
    continue;
  }

  itemToUpdate = {
    id: record.id,
    appointments: record.getCellValue("appointment") || [],
  };
  break;
}

console.log("itemToUpdate", itemToUpdate);

if (itemToUpdate) {
  // update

  const exists =
    itemToUpdate.appointments.filter((a) => a.id === item.id).length > 0;
  console.log("exists", exists);

  if (!exists) {
    const appointment = itemToUpdate.appointments;
    appointment.push({ id: item.id, name: item.id });
    await table.updateRecordAsync(itemToUpdate.id, {
      appointment: appointment,
    });
  }
} else {
  // create
  const newRecord = {
    date: item.date,
    organization: [{ id: item.organizationId }],
    schedule: [{ id: item.scheduleId }],
    period: [{ id: item.periodId }],
    appointment: [{ id: item.id }],
  };
  console.log("newRecord", newRecord);
  await table.createRecordAsync(newRecord);
}
