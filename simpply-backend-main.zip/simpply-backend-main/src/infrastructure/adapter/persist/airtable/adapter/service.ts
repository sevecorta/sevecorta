import { IServicePersist, IServiceDTO } from '@/core/persist/service'
import { injectable } from 'tsyringe'
import { AirtableClient } from '../client'
import { ServiceCollectionResponse, ServiceResponse } from '../schema/service'
import { AirtableTransform } from '../transform'

@injectable()
export class AirtableServiceAdapter implements IServicePersist {
  async search (organizationId: string): Promise<IServiceDTO[]> {
    const formula = `FIND('${organizationId}', {organization__record_id}) > 0`
    const resp = await AirtableClient.get('service', {
      params: { view: 'backend', filterByFormula: formula }
    })
    const data = ServiceCollectionResponse.parse(resp.data)

    return data.records.map((obj) => AirtableTransform.toService(obj))
  }

  async findById (id: string): Promise<IServiceDTO> {
    const resp = await AirtableClient.get(`service/${id}`)
    const data = ServiceResponse.parse(resp.data)

    return AirtableTransform.toService(data)
  }
}
