import { z } from 'zod'

export const AppointmentPatientResponse = z.object({
  id: z.string(),
  fields: z.object({
    appointment: z.array(z.string()),
    customer: z.array(z.string())
  }),
  createdTime: z.string()
})

export const AppointmentPatientCollectionResponse = z.object({
  records: z.array(AppointmentPatientResponse)
})
