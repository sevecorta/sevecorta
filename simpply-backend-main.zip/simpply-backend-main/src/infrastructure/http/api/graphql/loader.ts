import { PeriodFindById } from '@/application/period/find-by-id'
import { IPeriodDTO } from '@/core/persist/period'
import { DependencyContainer } from 'tsyringe'
import DataLoader from 'dataloader'

export class Loader {
  periodLoader: DataLoader<string, IPeriodDTO>

  constructor (container: DependencyContainer) {
    this.periodLoader = new DataLoader(async (keys: readonly string[]) => {
      const promises = keys.map(async (key) => {
        const findById = container.resolve(PeriodFindById)
        return await findById.execute({ id: key })
      })
      return await Promise.all(promises)
    })
  }
}
