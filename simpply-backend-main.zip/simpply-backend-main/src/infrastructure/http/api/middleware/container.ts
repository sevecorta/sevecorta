import * as express from 'express'
import { DependencyContainer } from 'tsyringe'

export function attachContainer (container: DependencyContainer) {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    req.container = container.createChildContainer()
    next()
  }
}
