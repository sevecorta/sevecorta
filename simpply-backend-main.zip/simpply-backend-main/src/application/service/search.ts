import { IServicePersist, IServiceDTO } from '@/core/persist/service'
import { inject, injectable } from 'tsyringe'
import { z } from 'zod'

const Request = z.object({
  organizationId: z.string().min(1)
})

@injectable()
export class ServiceSearch {
  constructor (
    @inject('ServicePersist')
    private readonly persist: IServicePersist
  ) {}

  async execute (dirty: z.infer<typeof Request>): Promise<IServiceDTO[]> {
    const data = Request.parse(dirty)

    const services = await this.persist.search(data.organizationId)
    return services
  }
}
