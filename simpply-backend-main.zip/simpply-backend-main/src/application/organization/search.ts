import { ILogger } from '@/core/ports/logger'
import { IOrganizationPersist, IOrganizationDTO } from '@/core/persist/organization'
import { inject, injectable } from 'tsyringe'

@injectable()
export class OrganizationSearch {
  constructor (
    @inject('OrganizationPersist')
    private readonly persist: IOrganizationPersist,

    @inject('Logger')
    private readonly logger: ILogger
  ) {}

  async execute (): Promise<IOrganizationDTO[]> {
    const items = await this.persist.search()
    this.logger.debug('items', items)
    return items
  }
}
