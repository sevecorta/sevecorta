import { IPeriodPersist, IPeriodDTO } from '@/core/persist/period'
import { inject, injectable } from 'tsyringe'

interface Request {
  id: string
}

@injectable()
export class PeriodFindById {
  constructor (
    @inject('PeriodPersist')
    private readonly persist: IPeriodPersist
  ) {}

  async execute (data: Request): Promise<IPeriodDTO> {
    const item = await this.persist.findById(data.id)
    return item
  }
}
