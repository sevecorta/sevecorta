import { IDateUtil } from '@/core/ports/date-util'
import { container } from 'tsyringe'

test('now debe devolver la fecha actual', async () => {
  const dateMock = new Date(2021, 10, 20)
  jest.useFakeTimers()
  jest.setSystemTime(dateMock)

  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const now = dateUtil.now()

  expect(now.valueOf()).toEqual(dateMock.getTime())
  jest.useRealTimers()
})

test('parse debe transformar texto a una fecha', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const date = dateUtil.parse('2021-10-20')

  expect(date.format('YYYY-MM-DD')).toEqual('2021-10-20')
})

test('tz debe devolver fecha con zona horaria', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const limaDate = dateUtil.tz('2021-10-20', 'America/Lima')
  const santiagoDate = dateUtil.tz('2021-10-20', 'America/Santiago')

  expect(limaDate.toISOString()).toEqual('2021-10-20T05:00:00.000Z')
  expect(santiagoDate.toISOString()).toEqual('2021-10-20T03:00:00.000Z')
})

test('startOf debe devolver inicio de una fecha por unidad', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const startOfMonth = dateUtil.parse('2021-10-20').startOf('month')
  const startOfDay = dateUtil.parse('2021-10-20 15:00').startOf('day')
  const startOfHour = dateUtil.parse('2021-10-20 15:45').startOf('hour')

  expect(startOfMonth.format('YYYY-MM-DD')).toEqual('2021-10-01')
  expect(startOfDay.format('YYYY-MM-DD HH:mm:ss')).toEqual('2021-10-20 00:00:00')
  expect(startOfHour.format('YYYY-MM-DD HH:mm:ss')).toEqual('2021-10-20 15:00:00')
})

test('endOf debe devolver fin de una fecha por unidad', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const endOfMonth = dateUtil.parse('2021-10-20').endOf('month')
  const endOfDay = dateUtil.parse('2021-10-20 15:00').endOf('day')
  const endOfHour = dateUtil.parse('2021-10-20 15:45').endOf('hour')

  expect(endOfMonth.format('YYYY-MM-DD')).toEqual('2021-10-31')
  expect(endOfDay.format('YYYY-MM-DD HH:mm:ss')).toEqual('2021-10-20 23:59:59')
  expect(endOfHour.format('YYYY-MM-DD HH:mm:ss')).toEqual('2021-10-20 15:59:59')
})

test('add debe agregar o restar tiempo por unidad', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const initialMonth = dateUtil.parse('2021-10-20')
  const initialDay = dateUtil.parse('2021-10-20')
  const initialHour = dateUtil.parse('2021-10-20')

  expect(initialMonth.add(1, 'month').format('YYYY-MM-DD')).toEqual('2021-11-20')
  expect(initialMonth.add(-1, 'month').format('YYYY-MM-DD')).toEqual('2021-09-20')
  expect(initialDay.add(1, 'day').format('YYYY-MM-DD')).toEqual('2021-10-21')
  expect(initialDay.add(-1, 'day').format('YYYY-MM-DD')).toEqual('2021-10-19')
  expect(initialHour.add(1, 'hour').format('YYYY-MM-DD HH:mm')).toEqual('2021-10-20 01:00')
  expect(initialHour.add(-1, 'hour').format('YYYY-MM-DD HH:mm')).toEqual('2021-10-19 23:00')
})

test('tz debe transformar una fecha a otra zona horaria', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const limaDate = dateUtil.tz('2021-10-20 12:00', 'America/Lima')
  const santiagoDate = limaDate.tz('America/Santiago')

  expect(santiagoDate.hour()).toEqual(14)
  expect(limaDate.toISOString()).toEqual('2021-10-20T17:00:00.000Z')
  expect(santiagoDate.toISOString()).toEqual('2021-10-20T17:00:00.000Z')
})

test('year debe asignar o recuperar año', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const date = dateUtil.parse('2021-10-20')

  expect(date.year()).toEqual(2021)
  expect(date.year(2022).year()).toEqual(2022)
})

test('month debe asignar o recuperar mes', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const date = dateUtil.parse('2021-10-20')

  expect(date.month()).toEqual(9)
  expect(date.month(10).month()).toEqual(10)
})

test('date debe asignar o recuperar día', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const date = dateUtil.parse('2021-10-20')

  expect(date.date()).toEqual(20)
  expect(date.date(10).date()).toEqual(10)
})

test('hour debe asignar o recuperar hora', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const date = dateUtil.parse('2021-10-20 15:00')

  expect(date.hour()).toEqual(15)
  expect(date.hour(17).hour()).toEqual(17)
})

test('minute debe asignar o recuperar minutos', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const date = dateUtil.parse('2021-10-20 15:35')

  expect(date.minute()).toEqual(35)
  expect(date.minute(40).minute()).toEqual(40)
})

test('second debe asignar o recuperar segundos', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const date = dateUtil.parse('2021-10-20 15:35:25')

  expect(date.second()).toEqual(25)
  expect(date.second(45).second()).toEqual(45)
})

test('isoWeekday debe recuperar el numero de día en la semana en formato iso', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  expect(dateUtil.parse('2021-10-25').isoWeekday()).toEqual(1)
  expect(dateUtil.parse('2021-10-26').isoWeekday()).toEqual(2)
  expect(dateUtil.parse('2021-10-27').isoWeekday()).toEqual(3)
  expect(dateUtil.parse('2021-10-28').isoWeekday()).toEqual(4)
  expect(dateUtil.parse('2021-10-29').isoWeekday()).toEqual(5)
  expect(dateUtil.parse('2021-10-30').isoWeekday()).toEqual(6)
  expect(dateUtil.parse('2021-10-31').isoWeekday()).toEqual(7)
})

test('isoWeekday debe asignar el numero de día en la semana en formato iso', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  expect(dateUtil.parse('2021-10-25').isoWeekday(7).format('YYYY-MM-DD')).toEqual('2021-10-31')
})

test('clone debe clonar objeto de fecha', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const date1 = dateUtil.parse('2021-10-20')
  const date2 = date1.clone() // Deberia permitir editar variables sin referencia

  expect(date1.date(25).format('YYYY-MM-DD')).toEqual('2021-10-25')
  expect(date2.format('YYYY-MM-DD')).toEqual('2021-10-20')
})

test('format debe devolver la fecha en diferentes formatos', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  const date = dateUtil.parse('2021-10-20 10:11:12')

  expect(date.format('YYYY-MM')).toEqual('2021-10')
  expect(date.format('YYYY-MM-DD')).toEqual('2021-10-20')
  expect(date.format('YYYY-MM-DD HH')).toEqual('2021-10-20 10')
  expect(date.format('YYYY-MM-DD HH:mm')).toEqual('2021-10-20 10:11')
  expect(date.format('YYYY-MM-DD HH:mm:ss')).toEqual('2021-10-20 10:11:12')
})

test('daysInMonth debe devolver el total de días del mes', async () => {
  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  expect(dateUtil.parse('2021-10-20').daysInMonth()).toEqual(31)
  expect(dateUtil.parse('2022-02-20').daysInMonth()).toEqual(28)
})
