import axios from 'axios'
import { FlowclConfig } from './config'

export const FlowclClient = axios.create({
  baseURL: FlowclConfig.baseUrl,
  timeout: FlowclConfig.apiTimeout
})
