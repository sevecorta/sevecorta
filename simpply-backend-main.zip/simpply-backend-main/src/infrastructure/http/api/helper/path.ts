export const paymentRouteBase = '/api/payment'
export const paymentRouteConfirmation = '/media/flowcl/confirmation'
export const paymentRouteReturn = '/media/flowcl/return/appointment/:appointmentId'

export const PathUtils = {
  getPaymentUrlConfirmation (urlBase: string) {
    return urlBase + paymentRouteBase + paymentRouteConfirmation
  },

  getPaymentUrlReturn (urlBase: string, appointmentId: string) {
    return (
      urlBase +
      paymentRouteBase +
      paymentRouteReturn.replace(':appointmentId', appointmentId)
    )
  }
}
