import React from "react";
import {Card, CardContent, Grid, Typography} from "@material-ui/core";
import {AccessTime, Map} from "@material-ui/icons";

const ServiceDetail = ({service}) => {
    return(
        <Card style={{border: "1px solid rgba(32, 69, 178, 0.3)", boxShadow: "0px 2px 4px rgba(57, 40, 166, 0.15)"}}>
            <CardContent>
                <Typography style={{borderBottom: "1px solid rgba(32, 69, 178, 0.3)", marginBottom: 25}}>{service.name}</Typography>
                <Grid container spacing={2}  style={{marginBottom: 15}}>
                    <Grid item>
                        <Map/>
                    </Grid>
                    <Grid item>
                        <Typography style={{fontWeight: "bold"}}>Lugar de atención</Typography>
                        <Typography>{service.location}</Typography>
                    </Grid>
                </Grid>
                <Grid container spacing={2}  style={{marginBottom: 15}}>
                    <Grid item>
                        <AccessTime/>
                    </Grid>
                    <Grid item>
                        <Typography style={{fontWeight: "bold"}}>Resultados online </Typography>
                        <Typography>en {service.resultTime} días</Typography>
                    </Grid>
                </Grid>
                <Typography variant={"body2"}  style={{marginBottom: 15}}>{service.observations}</Typography>
                <Typography style={{textAlign: "center", fontWeight: "bold"}}>Valor total por examen: <span style={{color: "#2145b2"}}>${service.amount}</span></Typography>
            </CardContent>
        </Card>
    )
}

export default ServiceDetail;