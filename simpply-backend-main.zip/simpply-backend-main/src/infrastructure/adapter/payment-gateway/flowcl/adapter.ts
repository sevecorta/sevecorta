import { ILogger } from '@/core/ports/logger'
import { IPaymentGatewayCreateInput, IPaymentGatewayCreateOutput, IPaymentGateway } from '@/core/ports/payment-gateway'
import { inject, injectable } from 'tsyringe'
import { FlowclClient } from './client'
import { FlowclConfig } from './config'
import { PaymentCreateResponse, PaymentStatusResponse } from './schema'
import { FlowclUtils } from './utils'

@injectable()
export class FlowclPaymentGatewayAdapter implements IPaymentGateway {
  constructor (
    @inject('Logger') private readonly logger: ILogger
  ) {}

  async create (params: IPaymentGatewayCreateInput): Promise<IPaymentGatewayCreateOutput> {
    const payload: Record<string, unknown> = {
      apiKey: FlowclConfig.apiKey,
      subject: params.subject,
      currency: params.currency,
      amount: params.amount,
      email: params.email,
      commerceOrder: params.order,
      urlConfirmation: params.urlConfirmation,
      urlReturn: params.urlReturn
    }
    const sign = FlowclUtils.sign(payload, FlowclConfig.apiSecretKey)
    const form = new URLSearchParams()
    form.append('s', sign)
    for (const k of Object.keys(payload)) {
      form.append(k, String(payload[k]))
    }

    this.logger.debug('form', form)
    const resp = await FlowclClient.post('payment/create', form)
    const data = PaymentCreateResponse.parse(resp.data)

    return {
      token: data.token,
      url: data.url,
      order: String(data.flowOrder)
    }
  }

  async isPaidByToken (token: string): Promise<boolean> {
    const payload: Record<string, unknown> = {
      apiKey: FlowclConfig.apiKey,
      token: token
    }
    const sign = FlowclUtils.sign(payload, FlowclConfig.apiSecretKey)
    const resp = await FlowclClient.get('payment/getStatus', {
      params: {
        ...payload,
        s: sign
      }
    })
    const data = PaymentStatusResponse.parse(resp.data)
    return data.status === 2
  }
}
