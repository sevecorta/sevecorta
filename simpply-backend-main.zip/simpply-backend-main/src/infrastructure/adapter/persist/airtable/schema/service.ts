import { z } from 'zod'

export const ServiceResponse = z.object({
  id: z.string(),
  fields: z.object({
    name: z.string(),
    description: z.string(),
    amount: z.number()
  }),
  createdTime: z.string()
})

export const ServiceCollectionResponse = z.object({
  records: z.array(ServiceResponse)
})
