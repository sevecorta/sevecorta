export const AirtableConfig = {
  baseId: process.env.AIRTABLE_BASE_ID ?? 'BASE_ID',
  apiKey: process.env.AIRTABLE_API_KEY ?? 'API_KEY',
  apiTimeout: parseInt(process.env.AIRTABLE_API_TIMEOUT ?? '3000')
}
