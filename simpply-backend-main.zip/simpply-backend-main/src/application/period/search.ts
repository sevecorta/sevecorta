import { IPeriodPersist, IPeriodDTO } from '@/core/persist/period'
import { inject, injectable } from 'tsyringe'

interface Request {
  organizationId: string
}

@injectable()
export class PeriodSearch {
  constructor (
    @inject('PeriodPersist') private readonly persist: IPeriodPersist
  ) {}

  async execute (data: Request): Promise<IPeriodDTO[]> {
    const periods = await this.persist.search(data.organizationId)
    return periods
  }
}
