import serverless from 'serverless-http'
import { container } from 'tsyringe'
import { MakeAPI } from './server'

export const handler = serverless(MakeAPI(container))
