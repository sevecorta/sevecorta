import { AirtableOrganizationAdapter } from '@/infrastructure/adapter/persist/airtable/adapter/organization'
import nock from 'nock'

describe('Search', () => {
  test('Debe devolver organizaciones', async () => {
    const scope = nock('https://api.airtable.com', {
      reqheaders: { authorization: /Bearer/ }
    })
      .get(/v0\/\w+\/organization/)
      .query({ view: 'backend' })
      .reply(200, {
        records: [
          {
            id: '',
            createdTime: '',
            fields: {
              name: ''
            }
          }
        ]
      })

    const repositoty = new AirtableOrganizationAdapter()
    const items = await repositoty.search()
    expect(items.length).toBe(1)
    scope.done()
  })
})

describe('FindById', () => {
  test('Debe devolver organización por id', async () => {
    const organizationId = 'fakeid'

    const scope = nock('https://api.airtable.com', {
      reqheaders: { authorization: /Bearer/ }
    })
      .get(/v0\/\w+\/organization\/fakeid/)
      .reply(200, {
        id: organizationId,
        createdTime: '',
        fields: {
          name: ''
        }
      })

    const repositoty = new AirtableOrganizationAdapter()
    const item = await repositoty.findById(organizationId)
    expect(item.id).toBe(organizationId)
    scope.done()
  })
})
