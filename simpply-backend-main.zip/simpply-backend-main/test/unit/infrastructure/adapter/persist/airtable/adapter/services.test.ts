import { AirtableServiceAdapter } from '@/infrastructure/adapter/persist/airtable/adapter/service'
import nock from 'nock'

describe('Search', () => {
  test('Debe devolver servicios', async () => {
    const organizationId = 'fakeid'

    const scope = nock('https://api.airtable.com', {
      reqheaders: { authorization: /Bearer/ }
    })
      .get(/v0\/\w+\/service/)
      .query({
        view: 'backend',
        filterByFormula: `FIND('${organizationId}', {organization__record_id}) > 0`
      })
      .reply(200, {
        records: [
          {
            id: '',
            createdTime: '',
            fields: {
              name: '',
              description: '',
              amount: 0
            }
          }
        ]
      })

    const repositoty = new AirtableServiceAdapter()
    const items = await repositoty.search(organizationId)
    expect(items.length).toBe(1)
    scope.done()
  })
})
