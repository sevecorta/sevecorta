import { z } from 'zod'

export const PeriodResponse = z.object({
  id: z.string(),
  fields: z.object({
    description: z.string(),
    hour_start: z.string(),
    hour_end: z.string()
  }),
  createdTime: z.string()
})

export const PeriodCollectionResponse = z.object({
  records: z.array(PeriodResponse)
})
