import { ICustomerPersist, ICustomerDTO } from '@/core/persist/customer'
import { inject, injectable } from 'tsyringe'

interface Request {
  appointmentId: string
}

@injectable()
export class CustomerSearchByAppointmentId {
  constructor (
    @inject('CustomerPersist')
    private readonly customerPersist: ICustomerPersist
  ) {}

  async execute (data: Request): Promise<ICustomerDTO[]> {
    return await this.customerPersist.searchByAppointmentId(data.appointmentId)
  }
}
