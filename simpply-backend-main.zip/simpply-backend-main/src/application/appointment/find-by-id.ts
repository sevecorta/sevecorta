import { IAppointmentPersist, IAppointmentDTO } from '@/core/persist/appointment'
import { inject, injectable } from 'tsyringe'

interface Request {
  id: string
}

@injectable()
export class AppointmentFindById {
  constructor (
    @inject('AppointmentPersist')
    private readonly persist: IAppointmentPersist
  ) {}

  async execute (data: Request): Promise<IAppointmentDTO> {
    const item = await this.persist.findById(data.id)
    return item
  }
}
