import { IUniqueID } from '@/core/ports/unique-id'
import short from 'short-uuid'

export class UniqueIDAdapter implements IUniqueID {
  generate (): string {
    return short.generate()
  }
}
