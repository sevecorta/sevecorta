import { IServicePersist, IServiceDTO } from '@/core/persist/service'
import { inject, injectable } from 'tsyringe'

interface Request {
  id: string
}

@injectable()
export class ServiceFindById {
  constructor (
    @inject('ServicePersist')
    private readonly persist: IServicePersist
  ) {}

  async execute (data: Request): Promise<IServiceDTO> {
    const service = await this.persist.findById(data.id)
    return service
  }
}
