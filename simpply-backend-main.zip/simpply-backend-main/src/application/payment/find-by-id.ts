import { ILogger } from '@/core/ports/logger'
import { IAppointmentPaymentPersist, IPaymentDTO } from '@/core/persist/appointment-payment'
import { inject, injectable } from 'tsyringe'

interface Request {
  id: string
}

@injectable()
export class PaymentFindById {
  constructor (
    @inject('AppointmentPaymentPersist')
    private readonly appointmentPaymentPersist: IAppointmentPaymentPersist,

    @inject('Logger')
    private readonly logger: ILogger
  ) {}

  async execute (data: Request): Promise<IPaymentDTO> {
    this.logger.debug('data', data)
    const payment = await this.appointmentPaymentPersist.findById(data.id)
    return payment
  }
}
