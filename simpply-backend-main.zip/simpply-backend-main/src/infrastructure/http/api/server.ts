import { json as bodyJSON, urlencoded as bodyUrlEncoded } from 'body-parser'
import rTracer from 'cls-rtracer'
import cors from 'cors'
import express from 'express'
import { DependencyContainer } from 'tsyringe'
import { attachContainer } from './middleware/container'
import { router as graphqlRouter } from './router/graphql'
import { router as paymentRouter } from './router/payment'

export function MakeAPI (container: DependencyContainer): express.Express {
  const api = express()
  api.use(cors())
  api.use(bodyJSON())
  api.use(bodyUrlEncoded({ extended: true }))
  api.use(
    rTracer.expressMiddleware({
      echoHeader: true,
      useHeader: true
    })
  )
  api.use(attachContainer(container))
  api.use('/api/graphql', graphqlRouter)
  api.use('/api/payment', paymentRouter)
  return api
}
