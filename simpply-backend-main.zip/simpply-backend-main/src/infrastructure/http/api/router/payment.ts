import { PaymentFindUrlById } from '@/application/payment/find-url-by-id'
import { PaymentUpdateStateByToken } from '@/application/payment/update-state-by-token'
import { paymentRouteReturn, paymentRouteConfirmation } from '../helper/path'
import { Router } from 'express'
import { handler } from '../helper/request'

export const router = Router()

router.get('/pay/:id', handler(async (req, res) => {
  const instance = req.container.resolve(PaymentFindUrlById)
  const paymentUrl = await instance.execute({ id: req.params.id })
  res.redirect(paymentUrl)
}))

router.post(paymentRouteConfirmation, handler(async (req, res) => {
  // flow requiere status 200 para evitar notificar error
  res.status(200).send()
}))

router.post(paymentRouteReturn, handler(async (req, res) => {
  const token: string = req.body.token
  const paymentUpdateState = req.container.resolve(PaymentUpdateStateByToken)
  await paymentUpdateState.execute({ token: token })

  res.redirect(`https://simpply-dev.netlify.app/confirmacion/${req.params.appointmentId}`)
}))
