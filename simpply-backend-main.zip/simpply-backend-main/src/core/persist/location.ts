export interface ILocationDTO {
  id: string
  name: string
  amount: number
}

export interface ILocationPersist {
  findById: (id: string) => Promise<ILocationDTO>
  search: (organizationId: string) => Promise<ILocationDTO[]>
}
