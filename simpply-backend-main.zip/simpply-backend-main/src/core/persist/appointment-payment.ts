export interface IPaymentDTO {
  id: string
  order: string
  amount: number
  state: 'pending' | 'success' | 'error'
  createdTime: string
  paymentOrder: string
  paymentToken: string
  paymentUrl: string
}

export interface IAppointmentPaymentCreateInput {
  appointmentId: string
  amount: number
  state: 'pending'
  order: string
  paymentPayer: string
  paymentToken: string
  paymentOrder: string
  paymentUrl: string
}

export interface IAppointmentPaymentPersist {
  create: (data: IAppointmentPaymentCreateInput) => Promise<string>
  findById: (id: string) => Promise<IPaymentDTO>
  findByToken: (token: string) => Promise<IPaymentDTO>
  searchByAppointmentId: (appointmentId: string) => Promise<IPaymentDTO[]>
  updateState: (id: string, state: 'success' | 'error') => Promise<void>
}
