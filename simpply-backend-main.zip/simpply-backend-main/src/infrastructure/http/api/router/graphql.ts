import { graphqlHTTP } from 'express-graphql'
import { Router } from 'express'
import { schema } from '../graphql'
import { Loader } from '../graphql/loader'
import { handler } from '../helper/request'
import { IContext } from '../graphql/context'

export const router = Router()

router.use('/', handler(async (req, res) => {
  const ctx: IContext = {
    request: req,
    loader: new Loader(req.container)
  }

  await graphqlHTTP({
    schema: schema,
    graphiql: {
      headerEditorEnabled: true
    },
    context: ctx
  })(req, res)
}))
