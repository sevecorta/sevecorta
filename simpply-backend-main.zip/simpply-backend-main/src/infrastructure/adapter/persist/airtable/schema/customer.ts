import { z } from 'zod'

export const CustomerResponse = z.object({
  id: z.string(),
  fields: z.object({
    document_type: z.string(),
    document: z.string().default(''),
    first_name: z.string().default(''),
    last_name: z.string().default(''),
    email: z.string().default(''),
    phone: z.string().optional(),
    birthdate: z.string().optional(),
    address: z.string().optional()
  }),
  createdTime: z.string()
})

export const CustomerCollectionResponse = z.object({
  records: z.array(CustomerResponse)
})
