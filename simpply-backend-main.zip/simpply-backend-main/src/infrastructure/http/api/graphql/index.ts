import { makeExecutableSchema } from '@graphql-tools/schema'
import { resolver } from './resolver'
import { typeDefs } from './typedef'

export const schema = makeExecutableSchema({
  typeDefs: typeDefs,
  resolvers: resolver
})
