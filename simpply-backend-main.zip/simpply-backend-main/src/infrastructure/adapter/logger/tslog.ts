import { ILogger } from '@/core/ports/logger'
import rTracer from 'cls-rtracer'
import { ISettingsParam, Logger } from 'tslog'
import { Config } from '@/core/config'

export class LoggerAdapter implements ILogger {
  private readonly logger

  constructor () {
    let type: ISettingsParam['type'] = 'json'

    if (Config.environment === 'local') {
      type = 'pretty'
    }

    if (Config.environment === 'test') {
      type = 'hidden'
    }

    this.logger = new Logger({
      type,
      ignoreStackLevels: 4,
      displayFilePath: 'hidden',
      displayRequestId: false,
      requestId: (): string => {
        return rTracer.id() as string
      }
    })
  }

  debug (msg: string, ...args: any[]): void {
    this.logger.debug(msg, ...args)
  }

  error (msg: string, ...args: any[]): void {
    this.logger.error(msg, ...args)
  }
}
