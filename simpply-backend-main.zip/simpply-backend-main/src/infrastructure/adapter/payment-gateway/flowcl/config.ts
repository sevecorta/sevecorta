export const FlowclConfig = {
  baseUrl: process.env.FLOW_API_BASE_URL ?? 'BASE_URL',
  apiKey: process.env.FLOW_API_KEY ?? 'API_KEY',
  apiSecretKey: process.env.FLOW_API_SECRET_KEY ?? 'API_SECRET_KEY',
  apiTimeout: Number(process.env.FLOW_API_TIMEOUT ?? '3000')
}
