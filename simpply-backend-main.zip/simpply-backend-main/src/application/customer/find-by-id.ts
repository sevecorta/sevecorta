import { ICustomerPersist, ICustomerDTO } from '@/core/persist/customer'
import { inject, injectable } from 'tsyringe'

interface Request {
  id: string
}

@injectable()
export class CustomerFindById {
  constructor (
    @inject('CustomerPersist')
    private readonly customerPersist: ICustomerPersist
  ) {}

  async execute (data: Request): Promise<ICustomerDTO> {
    return await this.customerPersist.findById(data.id)
  }
}
