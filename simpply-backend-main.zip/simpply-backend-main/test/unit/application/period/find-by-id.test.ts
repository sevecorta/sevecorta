import { container } from 'tsyringe'
import { mock, when, instance, verifyAll } from 'strong-mock'
import { MockPeriodDTO } from '@test/mock/core/persist/dto'
import { IPeriodPersist } from '@/core/persist/period'
import { PeriodFindById } from '@/application/period/find-by-id'

test('Debe devolver turno por id', async () => {
  const periodMock = MockPeriodDTO()

  const persist = mock<IPeriodPersist>()
  when(persist.findById(periodMock.id)).thenResolve(periodMock)

  const scope = container.createChildContainer()
  scope.registerInstance('PeriodPersist', instance(persist))

  const application = scope.resolve(PeriodFindById)
  const item = await application.execute({ id: periodMock.id })

  expect(item.id).toEqual(periodMock.id)
  verifyAll()
})
