export interface IServiceDTO {
  id: string
  name: string
  amount: number
  description: string
}

export interface IServicePersist {
  search: (organizationId: string) => Promise<IServiceDTO[]>
  findById: (id: string) => Promise<IServiceDTO>
}
