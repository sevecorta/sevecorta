import { MakeAPI } from '@/infrastructure/http/api/server'
import request from 'supertest'
import { container } from 'tsyringe'
import { MockServiceDTO } from '@test/mock/core/persist/dto'
import { ServiceSearch } from '@/application/service/search'
import { mock, when, instance, verifyAll } from 'strong-mock'

test('Debe devolver lista de servicios por organización', async () => {
  const serviceMock = MockServiceDTO()
  const organizationId = 'recW5p0rNsxWpUn6w'

  const serviceSearch = mock<ServiceSearch>()
  when(serviceSearch.execute({ organizationId: organizationId })).thenResolve([serviceMock])

  const scope = container.createChildContainer()
  scope.registerInstance(ServiceSearch, instance(serviceSearch))

  const resp = await request(MakeAPI(scope))
    .post('/api/graphql')
    .send({
      query: `
            query ($organizationId: String!) {
              services(search: {organizationId: $organizationId}) {
                id
                name
                description
                amount
              }
            }
          `,
      variables: { organizationId }
    })

  expect(resp.status).toEqual(200)
  expect(resp.body).toHaveProperty('data')
  expect(resp.body.data).toHaveProperty('services')
  expect(resp.body.data.services.length).toEqual(1)
  expect(resp.body.data.services[0].id).toEqual(serviceMock.id)
  verifyAll()
})
