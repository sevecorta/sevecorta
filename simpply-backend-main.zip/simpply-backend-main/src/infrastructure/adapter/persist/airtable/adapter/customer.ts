import { ICustomerCreateInput, ICustomerPersist, ICustomerSearchByDocumentBulkInput, ICustomerDTO } from '@/core/persist/customer'
import { AirtableClient } from '../client'
import { CustomerCollectionResponse, CustomerResponse } from '../schema/customer'
import { AirtableTransform } from '../transform'
import { AppointmentPatientCollectionResponse } from '../schema/appointment-patient'

export class AirtableCustomerAdapter implements ICustomerPersist {
  async searchByDocumentBulk (input: ICustomerSearchByDocumentBulkInput): Promise<ICustomerDTO[]> {
    const conditions = []
    for (const d of input.items) {
      conditions.push(
        `AND({document} = '${d.document}', {document_type} = '${d.documentType}')`
      )
    }

    const formula = `OR(${conditions.join(',')})`
    const resp = await AirtableClient.get(
      `customer?view=Grid%20view&filterByFormula=${formula}`
    )

    const data = CustomerCollectionResponse.parse(resp.data)
    return data.records.map((obj) => AirtableTransform.toCustomer(obj))
  }

  async createBulk (input: ICustomerCreateInput): Promise<string[]> {
    const body = {
      records: input.items.map((o) => ({
        fields: {
          document_type: o.documentType,
          document: o.document,
          first_name: o.firstName,
          last_name: o.lastName,
          email: o.email,
          phone: o.phone,
          birthdate: o.birthdate,
          address: o.address
        }
      }))
    }

    const resp = await AirtableClient.post('customer', body)

    const data = CustomerCollectionResponse.parse(resp.data)
    return data.records.map((obj) => obj.id)
  }

  async findById (id: string): Promise<ICustomerDTO> {
    const resp = await AirtableClient.get(`customer/${id}`)
    const data = CustomerResponse.parse(resp.data)

    return AirtableTransform.toCustomer(data)
  }

  async searchByAppointmentId (appointmentId: string): Promise<ICustomerDTO[]> {
    const detailFormula = `{appointment} = '${appointmentId}'`
    const detailResp = await AirtableClient.get(
      `appointment_patient?view=Grid%20view&filterByFormula=${detailFormula}`
    )

    const detailResult = AppointmentPatientCollectionResponse.parse(detailResp.data)

    const customerConditions = []
    for (const detail of detailResult.records) {
      const customerId = detail.fields.customer[0]
      customerConditions.push(`AND({record_id} = '${customerId}')`)
    }

    const customerFormula = `OR(${customerConditions.join(',')})`
    const customerResp = await AirtableClient.get(
      `customer?view=Grid%20view&filterByFormula=${customerFormula}`
    )

    const data = CustomerCollectionResponse.parse(customerResp.data)
    return data.records.map((item) => AirtableTransform.toCustomer(item))
  }
}
