function getLinkId(link) {
  if (link && link.length > 0) {
    return link[0].id;
  }
}

let inputConfig = input.config();
let table = base.getTable("appointment");
let view = table.getView("backend");

let queryResult = await view.selectRecordsAsync({
  fields: ["date", "organization", "schedule", "period"],
  sorts: [{ field: "date", direction: "desc" }],
});

let item;

for (const record of queryResult.records) {
  if (inputConfig.record_id === record.id) {
    item = {
      id: record.id,
      date: record.getCellValue("date"),
      organizationId: getLinkId(record.getCellValue("organization")),
      scheduleId: getLinkId(record.getCellValue("schedule")),
      periodId: getLinkId(record.getCellValue("period")),
    };
    break;
  }
}

console.log("item", item);
output.set("item", JSON.stringify(item));
