import { container } from 'tsyringe'
import { mock, when, instance, verifyAll } from 'strong-mock'
import { MockPeriodDTO } from '@test/mock/core/persist/dto'
import { IPeriodPersist } from '@/core/persist/period'
import { PeriodSearch } from '@/application/period/search'

test('Debe devolver lista de turnos por organización', async () => {
  const periodMock = MockPeriodDTO()
  const organizationId = 'recW5p0rNsxWpUn6w'

  const persist = mock<IPeriodPersist>()
  when(persist.search(organizationId)).thenResolve([periodMock])

  const scope = container.createChildContainer()
  scope.registerInstance('PeriodPersist', instance(persist))

  const application = scope.resolve(PeriodSearch)
  const items = await application.execute({ organizationId })

  expect(items.length).toEqual(1)
  expect(items[0].id).toEqual(periodMock.id)
  verifyAll()
})
