import { MakeAPI } from '@/infrastructure/http/api/server'
import request from 'supertest'
import { container } from 'tsyringe'
import { mock, when, instance, verifyAll } from 'strong-mock'
import { CalendarGenerate } from '@/application/calendar/generate'

test('Debe devolver lista de servicios por organización', async () => {
  const organizationId = 'recW5p0rNsxWpUn6w'
  const year = 2021
  const month = 10

  const calendarGenerate = mock<CalendarGenerate>()
  when(calendarGenerate.execute({ organizationId, year, month })).thenResolve([])

  const scope = container.createChildContainer()
  scope.registerInstance(CalendarGenerate, instance(calendarGenerate))

  const resp = await request(MakeAPI(scope))
    .post('/api/graphql')
    .send({
      query: `
        query ($organizationId: String!, $year: Int!, $month: Int!) {
          calendar(search: {organizationId: $organizationId, year: $year, month: $month}) {
            scheduleId
            date
          }
        }
      `,
      variables: { organizationId, year, month }
    })

  expect(resp.status).toEqual(200)
  expect(resp.body).toHaveProperty('data')
  expect(resp.body.data).toHaveProperty('calendar')
  expect(resp.body.data.calendar.length).toEqual(0)
  verifyAll()
})
