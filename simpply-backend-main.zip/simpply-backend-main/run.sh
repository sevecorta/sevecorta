#!/usr/bin/env bash

function install {
  npm ci --loglevel=error --no-audit
}

function server {
  ./node_modules/.bin/serverless offline start
}

function build {
  ./node_modules/.bin/serverless package
}

function deploy {
  STAGE=${@:-dev}
  ./node_modules/.bin/serverless deploy --verbose --stage ${STAGE}
}

function test {
  ./node_modules/.bin/tsc -p tsconfig.json --noEmit && \
  ./node_modules/.bin/ts-standard && \
  ./node_modules/.bin/jest --verbose --coverage --runInBand "$@"
}

function docs {
  OPENAPI_DIR=./docs/openapi
  ./node_modules/.bin/swagger-cli validate "$OPENAPI_DIR/src/index.yml" && \
  ./node_modules/.bin/swagger-cli bundle "$OPENAPI_DIR/src/index.yml" --outfile "$OPENAPI_DIR/api.yml" --type yaml
}

function help {
  printf "$0 <task> [args]\n"
  printf "\nTasks:\n"
  compgen -A function | grep -v "^_" | cat -n
  printf '\nOther utility tasks are in the tools directory\n'
  printf "\n"
}

${@:-help}
