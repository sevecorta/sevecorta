import { DependencyContainer } from 'tsyringe'

declare global {
  namespace Express {
    interface Request {
      // set by middleware container
      container: DependencyContainer

      // set by apigateway
      apiGateway: {
        event: {
          requestContext: {
            domainProtocol: string
            domainName: string
            stage: string
          }
        }
      }
    }
  }
}
