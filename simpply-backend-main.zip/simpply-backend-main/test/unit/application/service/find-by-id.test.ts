import { IServicePersist } from '@/core/persist/service'
import { ServiceFindById } from '@/application/service/find-by-id'
import { container } from 'tsyringe'
import { mock, when, instance, verifyAll } from 'strong-mock'
import { MockServiceDTO } from '@test/mock/core/persist/dto'

test('Debe devolver servicio por id', async () => {
  const serviceMock = MockServiceDTO()

  const persist = mock<IServicePersist>()
  when(persist.findById(serviceMock.id)).thenResolve(serviceMock)

  const scope = container.createChildContainer()
  scope.registerInstance('ServicePersist', instance(persist))

  const application = scope.resolve(ServiceFindById)
  const item = await application.execute({ id: serviceMock.id })

  expect(item.id).toEqual(serviceMock.id)
  verifyAll()
})
