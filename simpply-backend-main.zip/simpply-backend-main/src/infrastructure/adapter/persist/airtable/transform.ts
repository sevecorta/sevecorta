import { ICustomerDTO } from '@/core/persist/customer'
import { IServiceDTO } from '@/core/persist/service'
import { CustomerResponse } from './schema/customer'
import { ServiceResponse } from './schema/service'
import { PeriodResponse } from './schema/period'
import { AppointmentPaymentResponse } from './schema/appointment-payment'
import { IPeriodDTO } from '@/core/persist/period'
import { IPaymentDTO } from '@/core/persist/appointment-payment'
import { z } from 'zod'

export const AirtableTransform = {
  toService (data: z.infer<typeof ServiceResponse>): IServiceDTO {
    return {
      id: data.id,
      name: data.fields.name,
      description: data.fields.description,
      amount: data.fields.amount
    }
  },

  toCustomer (data: z.infer<typeof CustomerResponse>): ICustomerDTO {
    return {
      id: data.id,
      document: data.fields.document,
      documentType: data.fields.document_type,
      firstName: data.fields.first_name,
      lastName: data.fields.last_name,
      email: data.fields.email,
      phone: data.fields.phone,
      birthdate: data.fields.birthdate,
      address: data.fields.address
    }
  },

  toPeriod (data: z.infer<typeof PeriodResponse>): IPeriodDTO {
    return {
      id: data.id,
      description: data.fields.description,
      hourStart: data.fields.hour_start,
      hourEnd: data.fields.hour_end
    }
  },

  toAppointmentPayment (data: z.infer<typeof AppointmentPaymentResponse>): IPaymentDTO {
    return {
      id: data.id,
      order: data.fields.order,
      amount: data.fields.amount,
      state: data.fields.state as IPaymentDTO['state'],
      createdTime: data.createdTime,
      paymentToken: data.fields.payment_token,
      paymentOrder: data.fields.payment_order,
      paymentUrl: data.fields.payment_url
    }
  }
}
