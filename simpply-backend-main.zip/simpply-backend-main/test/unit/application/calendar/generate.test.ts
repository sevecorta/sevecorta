import { container } from 'tsyringe'
import { ISchedulePersist } from '@/core/persist/schedule'
import { IPeriodPersist } from '@/core/persist/period'
import { IAppointmentPersist } from '@/core/persist/appointment'
import { CalendarGenerate } from '@/application/calendar/generate'
import { IDateUtil } from '@/core/ports/date-util'
import { MockPeriodDTO, MockScheduleDTO, MockAppointmentGroupByDateDTO } from '@test/mock/core/persist/dto'
import { mock, when, instance, verifyAll } from 'strong-mock'

test('Debe generar disponibilidad por organización todos los días de la semana', async () => {
  const periodMock = MockPeriodDTO()
  const scheduleMock = MockScheduleDTO({
    day: ['lun', 'mar', 'mie', 'jue', 'vie', 'sab', 'dom'],
    periodId: periodMock.id,
    slots: 20,
    dateStart: '2021-10-04',
    dateEnd: '2021-10-10'
  })
  const organizationId = 'recW5p0rNsxWpUn6w'

  const schedulePersist = mock<ISchedulePersist>()
  const periodPersist = mock<IPeriodPersist>()
  const appointmentPersist = mock<IAppointmentPersist>()

  when(schedulePersist.search(organizationId)).thenResolve([scheduleMock])
  when(periodPersist.search(organizationId)).thenResolve([periodMock])
  when(appointmentPersist.groupByDate(organizationId, 2021, 10)).thenResolve([])

  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  dateUtil.now = () => {
    return dateUtil.parse('2021-10-04')
  }

  const scope = container.createChildContainer()
  scope.registerInstance('SchedulePersist', instance(schedulePersist))
  scope.registerInstance('PeriodPersist', instance(periodPersist))
  scope.registerInstance('AppointmentPersist', instance(appointmentPersist))
  scope.registerInstance('DateUtil', dateUtil)

  const application = scope.resolve(CalendarGenerate)
  const items = await application.execute({ organizationId, year: 2021, month: 10 })

  const availabilityDates = [
    '2021-10-04',
    '2021-10-05',
    '2021-10-06',
    '2021-10-07',
    '2021-10-08',
    '2021-10-09',
    '2021-10-10'
  ]

  expect(items.length).toBe(availabilityDates.length)

  for (let idx = 0; idx < items.length; idx++) {
    const availabilityDate = availabilityDates[idx]
    const item = items[idx]

    expect(item.scheduleId).toBe(scheduleMock.id)
    expect(item.date).toBe(availabilityDate)
    expect(item.periods.length).toBe(1)
    expect(item.periods[0].periodId).toBe(periodMock.id)
    expect(item.periods[0].slots).toBe(20)
  }
  verifyAll()
})

test('Debe generar disponibilidad por organización solo algunos días de semana', async () => {
  const periodMock = MockPeriodDTO()
  const scheduleMock = MockScheduleDTO({
    day: ['lun', 'mie', 'vie'],
    periodId: periodMock.id,
    slots: 20,
    dateStart: '2021-10-04',
    dateEnd: '2021-10-10'
  })
  const organizationId = 'recW5p0rNsxWpUn6w'

  const schedulePersist = mock<ISchedulePersist>()
  const periodPersist = mock<IPeriodPersist>()
  const appointmentPersist = mock<IAppointmentPersist>()

  when(schedulePersist.search(organizationId)).thenResolve([scheduleMock])
  when(periodPersist.search(organizationId)).thenResolve([periodMock])
  when(appointmentPersist.groupByDate(organizationId, 2021, 10)).thenResolve([])

  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  dateUtil.now = () => {
    return dateUtil.parse('2021-10-04')
  }

  const scope = container.createChildContainer()
  scope.registerInstance('SchedulePersist', instance(schedulePersist))
  scope.registerInstance('PeriodPersist', instance(periodPersist))
  scope.registerInstance('AppointmentPersist', instance(appointmentPersist))
  scope.registerInstance('DateUtil', dateUtil)

  const application = scope.resolve(CalendarGenerate)
  const items = await application.execute({ organizationId, year: 2021, month: 10 })

  const availabilityDates = [
    '2021-10-04',
    '2021-10-06',
    '2021-10-08'
  ]

  expect(items.length).toBe(availabilityDates.length)

  for (let idx = 0; idx < items.length; idx++) {
    const availabilityDate = availabilityDates[idx]
    const item = items[idx]

    expect(item.scheduleId).toBe(scheduleMock.id)
    expect(item.date).toBe(availabilityDate)
    expect(item.periods.length).toBe(1)
    expect(item.periods[0].periodId).toBe(periodMock.id)
    expect(item.periods[0].slots).toBe(20)
  }
  verifyAll()
})

test('Debe generar disponibilidad por organización con slot descontado', async () => {
  const periodMock = MockPeriodDTO()
  const scheduleMock = MockScheduleDTO({
    day: ['lun', 'mar'],
    periodId: periodMock.id,
    slots: 20,
    dateStart: '2021-10-04',
    dateEnd: '2021-10-10'
  })
  const appointmentGroupByDateDto = MockAppointmentGroupByDateDTO({
    scheduleId: scheduleMock.id,
    periodId: periodMock.id,
    date: '2021-10-04',
    count: 15
  })
  const organizationId = 'recW5p0rNsxWpUn6w'

  const schedulePersist = mock<ISchedulePersist>()
  const periodPersist = mock<IPeriodPersist>()
  const appointmentPersist = mock<IAppointmentPersist>()

  when(schedulePersist.search(organizationId)).thenResolve([scheduleMock])
  when(periodPersist.search(organizationId)).thenResolve([periodMock])
  when(appointmentPersist.groupByDate(organizationId, 2021, 10)).thenResolve([appointmentGroupByDateDto])

  const dateUtil = container.resolve<IDateUtil>('DateUtil')
  dateUtil.now = () => {
    return dateUtil.parse('2021-10-04')
  }

  const scope = container.createChildContainer()
  scope.registerInstance('SchedulePersist', instance(schedulePersist))
  scope.registerInstance('PeriodPersist', instance(periodPersist))
  scope.registerInstance('AppointmentPersist', instance(appointmentPersist))
  scope.registerInstance('DateUtil', dateUtil)

  const application = scope.resolve(CalendarGenerate)
  const items = await application.execute({ organizationId, year: 2021, month: 10 })

  const availabilityDates = [
    '2021-10-04',
    '2021-10-05'
  ]

  expect(items.length).toBe(availabilityDates.length)

  for (let idx = 0; idx < items.length; idx++) {
    const availabilityDate = availabilityDates[idx]
    const item = items[idx]

    expect(item.scheduleId).toBe(scheduleMock.id)
    expect(item.date).toBe(availabilityDate)
    expect(item.periods.length).toBe(1)
    expect(item.periods[0].periodId).toBe(periodMock.id)

    if (appointmentGroupByDateDto.date === availabilityDate) {
      expect(item.periods[0].slots).toBe(5)
    } else {
      expect(item.periods[0].slots).toBe(20)
    }
  }
  verifyAll()
})
