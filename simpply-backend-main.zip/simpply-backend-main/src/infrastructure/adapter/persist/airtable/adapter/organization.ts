import { IOrganizationPersist, IOrganizationDTO } from '@/core/persist/organization'
import { AirtableClient } from '../client'
import { OrganizationCollectionResponse, OrganizationResponse } from '../schema/organization'

export class AirtableOrganizationAdapter implements IOrganizationPersist {
  async search (): Promise<IOrganizationDTO[]> {
    const resp = await AirtableClient.get('organization', {
      params: { view: 'backend' }
    })

    const data = OrganizationCollectionResponse.parse(resp.data)

    return data.records.map((organization) => ({
      id: organization.id,
      name: organization.fields.name
    }))
  }

  async findById (id: string): Promise<IOrganizationDTO> {
    const resp = await AirtableClient.get(`organization/${id}`)

    const data = OrganizationResponse.parse(resp.data)

    return {
      id: data.id,
      name: data.fields.name
    }
  }
}
