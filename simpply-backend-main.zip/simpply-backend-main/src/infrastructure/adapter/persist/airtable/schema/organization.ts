import { z } from 'zod'

export const OrganizationResponse = z.object({
  id: z.string(),
  fields: z.object({
    name: z.string()
  }),
  createdTime: z.string()
})

export const OrganizationCollectionResponse = z.object({
  records: z.array(OrganizationResponse)
})
