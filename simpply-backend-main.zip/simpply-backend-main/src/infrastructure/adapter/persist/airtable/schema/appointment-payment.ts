import { z } from 'zod'

export const AppointmentPaymentResponse = z.object({
  id: z.string(),
  fields: z.object({
    appointment: z.array(z.string()),
    order: z.string(),
    amount: z.number(),
    state: z.string(),
    payment_payer: z.string(),
    payment_token: z.string(),
    payment_order: z.string(),
    payment_url: z.string()
  }),
  createdTime: z.string()
})

export const AppointmentPaymentCollectionResponse = z.object({
  records: z.array(AppointmentPaymentResponse)
})
