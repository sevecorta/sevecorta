import { IPeriodPersist, IPeriodDTO } from '@/core/persist/period'
import { AirtableClient } from '../client'
import { PeriodCollectionResponse, PeriodResponse } from '../schema/period'
import { AirtableTransform } from '../transform'

export class AirtablePeriodAdapter implements IPeriodPersist {
  async search (organizationId: string): Promise<IPeriodDTO[]> {
    const formula = `FIND('${organizationId}', {organization__record_id}) > 0`
    const resp = await AirtableClient.get('period', {
      params: { view: 'backend', filterByFormula: formula }
    })
    const data = PeriodCollectionResponse.parse(resp.data)

    return data.records.map((obj) => AirtableTransform.toPeriod(obj))
  }

  async findById (id: string): Promise<IPeriodDTO> {
    const resp = await AirtableClient.get(`period/${id}`)
    const data = PeriodResponse.parse(resp.data)

    return AirtableTransform.toPeriod(data)
  }
}
