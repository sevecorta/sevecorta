import { ILocationPersist, ILocationDTO } from '@/core/persist/location'
import { inject, injectable } from 'tsyringe'

interface Request {
  organizationId: string
}

@injectable()
export class LocationSearch {
  constructor (
    @inject('LocationPersist')
    private readonly persist: ILocationPersist
  ) {}

  async execute (data: Request): Promise<ILocationDTO[]> {
    const periods = await this.persist.search(data.organizationId)
    return periods
  }
}
