import { IAppointmentPaymentPersist } from '@/core/persist/appointment-payment'
import { inject, injectable } from 'tsyringe'

interface Request {
  id: string
}

@injectable()
export class PaymentFindUrlById {
  constructor (
    @inject('AppointmentPaymentPersist')
    private readonly appointmentPaymentPersist: IAppointmentPaymentPersist
  ) {}

  async execute (data: Request): Promise<string> {
    const payment = await this.appointmentPaymentPersist.findById(data.id)
    return `${payment.paymentUrl}?token=${payment.paymentToken}`
  }
}
