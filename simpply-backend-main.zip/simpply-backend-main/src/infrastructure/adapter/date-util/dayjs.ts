import {
  IDateUtil,
  IDateUtilAction,
  DateUtilUnitType
} from '@/core/ports/date-util'
import dayjs from 'dayjs'
import dayjsUtc from 'dayjs/plugin/utc'
import dayjsTimezone from 'dayjs/plugin/timezone'
import dayjsIsSameOrBefore from 'dayjs/plugin/isSameOrBefore'
import dayjsIsoWeek from 'dayjs/plugin/isoWeek'

dayjs.extend(dayjsUtc)
dayjs.extend(dayjsTimezone)
dayjs.extend(dayjsIsSameOrBefore)
dayjs.extend(dayjsIsoWeek)

class DayjsDateUtilActionAdapter implements IDateUtilAction {
  private readonly _instance

  constructor (value: dayjs.Dayjs) {
    this._instance = value.clone()
  }

  startOf (unit: DateUtilUnitType): IDateUtilAction {
    return new DayjsDateUtilActionAdapter(this._instance.startOf(unit))
  }

  endOf (unit: DateUtilUnitType): IDateUtilAction {
    return new DayjsDateUtilActionAdapter(this._instance.endOf(unit))
  }

  valueOf (): number {
    return this._instance.valueOf()
  }

  format (template?: string): string {
    return this._instance.format(template)
  }

  add (value: number, unit: DateUtilUnitType): IDateUtilAction {
    return new DayjsDateUtilActionAdapter(this._instance.add(value, unit))
  }

  tz (timezone: string): IDateUtilAction {
    return new DayjsDateUtilActionAdapter(this._instance.tz(timezone))
  }

  clone (): IDateUtilAction {
    return new DayjsDateUtilActionAdapter(this._instance)
  }

  daysInMonth (): number {
    return this._instance.daysInMonth()
  }

  year (): number
  year (value: number): IDateUtilAction
  year (value?: number): number | IDateUtilAction {
    if (typeof value === 'undefined') {
      return this._instance.year()
    }

    return new DayjsDateUtilActionAdapter(this._instance.year(value))
  }

  month (): number
  month (value: number): IDateUtilAction
  month (value?: number): number | IDateUtilAction {
    if (typeof value === 'undefined') {
      return this._instance.month()
    }

    return new DayjsDateUtilActionAdapter(this._instance.month(value))
  }

  date (): number
  date (value: number): IDateUtilAction
  date (value?: number): number | IDateUtilAction {
    if (typeof value === 'undefined') {
      return this._instance.date()
    }

    return new DayjsDateUtilActionAdapter(this._instance.date(value))
  }

  hour (): number
  hour (value: number): IDateUtilAction
  hour (value?: number): number | IDateUtilAction {
    if (typeof value === 'undefined') {
      return this._instance.hour()
    }

    return new DayjsDateUtilActionAdapter(this._instance.hour(value))
  }

  minute (): number
  minute (value: number): IDateUtilAction
  minute (value?: number): number | IDateUtilAction {
    if (typeof value === 'undefined') {
      return this._instance.minute()
    }

    return new DayjsDateUtilActionAdapter(this._instance.minute(value))
  }

  second (): number
  second (value: number): IDateUtilAction
  second (value?: number): number | IDateUtilAction {
    if (typeof value === 'undefined') {
      return this._instance.second()
    }

    return new DayjsDateUtilActionAdapter(this._instance.second(value))
  }

  isoWeekday (): number
  isoWeekday (value: number): IDateUtilAction
  isoWeekday (value?: number): number | IDateUtilAction {
    if (typeof value === 'undefined') {
      return this._instance.isoWeekday()
    }

    return new DayjsDateUtilActionAdapter(this._instance.isoWeekday(value))
  }

  toISOString (): string {
    return this._instance.toISOString()
  }
}

export class DayjsDateUtilAdapter implements IDateUtil {
  now (): IDateUtilAction {
    return new DayjsDateUtilActionAdapter(dayjs())
  }

  tz (value: string, timezone: string): IDateUtilAction {
    return new DayjsDateUtilActionAdapter(dayjs.tz(value, timezone))
  }

  parse (value: string, format?: string): IDateUtilAction {
    return new DayjsDateUtilActionAdapter(dayjs(value, format))
  }
}
