import { container } from 'tsyringe'
import { IAppointmentGroupByDateDTO, IAppointmentDTO } from '@/core/persist/appointment'
import { ICustomerDTO } from '@/core/persist/customer'
import { IOrganizationDTO } from '@/core/persist/organization'
import { IServiceDTO } from '@/core/persist/service'
import { IPeriodDTO } from '@/core/persist/period'
import { ILocationDTO } from '@/core/persist/location'
import { IScheduleDTO } from '@/core/persist/schedule'
import { IUniqueID } from '@/core/ports/unique-id'

export function MockOrganizationDTO (attr: Partial<IOrganizationDTO> = {}): IOrganizationDTO {
  const uniqueid = container.resolve<IUniqueID>('UniqueID')
  return {
    id: uniqueid.generate(),
    name: '',
    ...attr
  }
}

export function MockAppointmentDTO (attr: Partial<IAppointmentDTO> = {}): IAppointmentDTO {
  const uniqueid = container.resolve<IUniqueID>('UniqueID')
  return {
    id: uniqueid.generate(),
    date: '',
    amount: 0,
    serviceId: '',
    organizationId: '',
    customerId: '',
    locationId: '',
    periodId: '',
    createdTime: '',
    ...attr
  }
}

export function MockAppointmentGroupByDateDTO (attr: Partial<IAppointmentGroupByDateDTO> = {}): IAppointmentGroupByDateDTO {
  return {
    scheduleId: '',
    periodId: '',
    date: '',
    count: 0,
    ...attr
  }
}

export function MockServiceDTO (attr: Partial<IServiceDTO> = {}): IServiceDTO {
  const uniqueid = container.resolve<IUniqueID>('UniqueID')
  return {
    id: uniqueid.generate(),
    name: '',
    description: '',
    amount: 0,
    ...attr
  }
}

export function MockCustomerDTO (attr: Partial<ICustomerDTO> = {}): ICustomerDTO {
  const uniqueid = container.resolve<IUniqueID>('UniqueID')
  return {
    id: uniqueid.generate(),
    documentType: '',
    document: '',
    firstName: '',
    lastName: '',
    email: '',
    ...attr
  }
}

export function MockPeriodDTO (attr: Partial<IPeriodDTO> = {}): IPeriodDTO {
  const uniqueid = container.resolve<IUniqueID>('UniqueID')
  return {
    id: uniqueid.generate(),
    description: '',
    hourStart: '',
    hourEnd: '',
    ...attr
  }
}

export function MockLocationDTO (attr: Partial<ILocationDTO> = {}): ILocationDTO {
  const uniqueid = container.resolve<IUniqueID>('UniqueID')
  return {
    id: uniqueid.generate(),
    name: '',
    amount: 0,
    ...attr
  }
}

export function MockScheduleDTO (attr: Partial<IScheduleDTO> = {}): IScheduleDTO {
  const uniqueid = container.resolve<IUniqueID>('UniqueID')
  return {
    id: uniqueid.generate(),
    dateStart: '',
    dateEnd: '',
    periodId: '',
    day: [],
    slots: 0,
    ...attr
  }
}
