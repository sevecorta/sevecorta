import { IAppointmentPaymentCreateInput, IAppointmentPaymentPersist, IPaymentDTO } from '@/core/persist/appointment-payment'
import { AppointmentPaymentCollectionResponse, AppointmentPaymentResponse } from '../schema/appointment-payment'
import { AirtableClient } from '../client'
import { AirtableTransform } from '../transform'

export class AirtableAppointmentPaymentAdapter implements IAppointmentPaymentPersist {
  async create (params: IAppointmentPaymentCreateInput): Promise<string> {
    const body = {
      records: [
        {
          fields: {
            appointment: [params.appointmentId],
            amount: params.amount,
            state: params.state,
            order: params.order,
            payment_payer: params.paymentPayer,
            payment_token: params.paymentToken,
            payment_order: params.paymentOrder,
            payment_url: params.paymentUrl
          }
        }
      ]
    }

    const resp = await AirtableClient.post('appointment_payment', body)
    const data = AppointmentPaymentCollectionResponse.parse(resp.data)

    return data.records[0].id
  }

  async findById (id: string): Promise<IPaymentDTO> {
    const resp = await AirtableClient.get(`appointment_payment/${id}`)
    const data = AppointmentPaymentResponse.parse(resp.data)

    return {
      id: data.id,
      order: data.fields.order,
      amount: data.fields.amount,
      state: data.fields.state as IPaymentDTO['state'],
      createdTime: data.createdTime,
      paymentToken: data.fields.payment_token,
      paymentOrder: data.fields.payment_order,
      paymentUrl: data.fields.payment_url
    }
  }

  async findByToken (token: string): Promise<IPaymentDTO> {
    const formula = `{payment_token} = '${token}'`
    const resp = await AirtableClient.get(
      `appointment_payment?view=Grid%20view&filterByFormula=${formula}`
    )

    const data = AppointmentPaymentCollectionResponse.parse(resp.data)
    if (data.records.length === 0) {
      throw new Error('Get payment by token not found')
    }

    return AirtableTransform.toAppointmentPayment(data.records[0])
  }

  async searchByAppointmentId (appointmentId: string): Promise<IPaymentDTO[]> {
    const formula = `{appointment} = '${appointmentId}'`
    const resp = await AirtableClient.get(
      `appointment_payment?view=Grid%20view&filterByFormula=${formula}`
    )
    const data = AppointmentPaymentCollectionResponse.parse(resp.data)
    return data.records.map((item) => AirtableTransform.toAppointmentPayment(item))
  }

  async updateState (id: string, state: string): Promise<void> {
    const body = {
      records: [
        {
          id: id,
          fields: {
            state: state
          }
        }
      ]
    }

    await AirtableClient.patch('appointment_payment', body)
  }
}
