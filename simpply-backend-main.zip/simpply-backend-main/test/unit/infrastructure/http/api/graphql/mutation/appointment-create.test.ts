import { MakeAPI } from '@/infrastructure/http/api/server'
import request from 'supertest'
import { container } from 'tsyringe'
import { mock, when, instance, verifyAll } from 'strong-mock'
import { AppointmentCreate } from '@/application/appointment/create'
import { AppointmentFindById } from '@/application/appointment/find-by-id'
import { MockAppointmentDTO } from '@test/mock/core/persist/dto'

test('Debe crear cita', async () => {
  const appointmentMock = MockAppointmentDTO()
  const input = {
    date: '2021-06-01',
    amount: 1000,
    organizationId: 'recW5p0rNsxWpUn6w',
    serviceId: 'rec3QhexlBAzfVnBl',
    scheduleId: 'recNxeg9vJAGxhojy',
    periodId: 'recBPCJjHzuh5Cx2H',
    locationId: 'recBPCJjHzuh5Cx2H',
    customer: {
      firstName: 'firstName',
      lastName: 'lastName',
      document: '11111111',
      documentType: 'RUT',
      email: 'prueba@email.com'
    },
    patients: [{
      firstName: 'firstName',
      lastName: 'lastName',
      document: '22222222',
      documentType: 'RUT',
      email: 'email',
      phone: '9999999',
      address: 'address',
      birthdate: '2021-01-01'
    }]
  }

  const appointmentCreate = mock<AppointmentCreate>()
  when(appointmentCreate.execute(input)).thenResolve(appointmentMock.id)

  const appointmentFindById = mock<AppointmentFindById>()
  when(appointmentFindById.execute({ id: appointmentMock.id })).thenResolve(appointmentMock)

  const scope = container.createChildContainer()
  scope.registerInstance(AppointmentCreate, instance(appointmentCreate))
  scope.registerInstance(AppointmentFindById, instance(appointmentFindById))

  const resp = await request(MakeAPI(scope))
    .post('/api/graphql')
    .send({
      query: `
          mutation($input: AppointmentCreateInput!) {
            appointmentCreate(input: $input) {
              id
            }
          }
        `,
      variables: {
        input: input
      }
    })

  expect(resp.status).toEqual(200)
  expect(resp.body).toHaveProperty('data')
  expect(resp.body.data).toHaveProperty('appointmentCreate')
  expect(resp.body.data.appointmentCreate.id).toEqual(appointmentMock.id)
  verifyAll()
})
