import { ILogger } from '@/core/ports/logger'
import { IAppointmentPaymentPersist, IPaymentDTO } from '@/core/persist/appointment-payment'
import { inject, injectable } from 'tsyringe'

interface Request {
  appointmentId: string
}

@injectable()
export class PaymentSearchByAppointmentId {
  constructor (
    @inject('AppointmentPaymentPersist')
    private readonly appointmentPaymentPersist: IAppointmentPaymentPersist,

    @inject('Logger')
    private readonly logger: ILogger
  ) {}

  async execute (data: Request): Promise<IPaymentDTO[]> {
    this.logger.debug('data', data)
    const items = await this.appointmentPaymentPersist.searchByAppointmentId(data.appointmentId)
    return items
  }
}
