export interface IOrganizationDTO {
  id: string
  name: string
}

export interface IOrganizationPersist {
  search: () => Promise<IOrganizationDTO[]>
  findById: (id: string) => Promise<IOrganizationDTO>
}
