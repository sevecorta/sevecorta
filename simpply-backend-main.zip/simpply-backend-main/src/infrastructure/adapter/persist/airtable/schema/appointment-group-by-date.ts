import { z } from 'zod'

export const AppointmentGroupByDateResponse = z.object({
  id: z.string(),
  fields: z.object({
    date: z.string(),
    organization: z.array(z.string()).min(1),
    schedule: z.array(z.string()).min(1),
    period: z.array(z.string()).min(1),
    appointment_count: z.number()
  }),
  createdTime: z.string()
})

export const AirtableAppointmentGroupByDateCollectionSchema = z.object({
  records: z.array(AppointmentGroupByDateResponse)
})
