export interface IPeriodDTO {
  id: string
  description: string
  hourStart: string
  hourEnd: string
}

export interface IPeriodPersist {
  search: (organizationId: string) => Promise<IPeriodDTO[]>
  findById: (id: string) => Promise<IPeriodDTO>
}
