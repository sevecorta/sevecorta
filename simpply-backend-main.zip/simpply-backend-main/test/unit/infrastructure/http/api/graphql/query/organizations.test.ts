import { MakeAPI } from '@/infrastructure/http/api/server'
import request from 'supertest'
import { container } from 'tsyringe'
import { mock, when, instance, verifyAll } from 'strong-mock'
import { MockOrganizationDTO } from '@test/mock/core/persist/dto'
import { OrganizationSearch } from '@/application/organization/search'

test('Debe devolver lista de organizaciones', async () => {
  const organizationMock = MockOrganizationDTO()

  const organizationSearch = mock<OrganizationSearch>()
  when(organizationSearch.execute()).thenResolve([organizationMock])

  const scope = container.createChildContainer()
  scope.registerInstance(OrganizationSearch, instance(organizationSearch))

  const resp = await request(MakeAPI(scope))
    .post('/api/graphql')
    .send({
      query: `
          {
            organizations {
              id
              name
            }
          }
        `
    })

  expect(resp.status).toEqual(200)
  expect(resp.body).toHaveProperty('data')
  expect(resp.body.data).toHaveProperty('organizations')
  expect(resp.body.data.organizations.length).toEqual(1)
  expect(resp.body.data.organizations[0].id).toEqual(organizationMock.id)
  verifyAll()
})
