import { IAppointmentPersist } from '@/core/persist/appointment'
import { IAppointmentPaymentPersist } from '@/core/persist/appointment-payment'
import { ICustomerPersist } from '@/core/persist/customer'
import { ILocationPersist } from '@/core/persist/location'
import { IOrganizationPersist } from '@/core/persist/organization'
import { IPeriodPersist } from '@/core/persist/period'
import { ISchedulePersist } from '@/core/persist/schedule'
import { IServicePersist } from '@/core/persist/service'
import { AirtableAppointmentPaymentAdapter } from '@/infrastructure/adapter/persist/airtable/adapter/appointment-payment'
import { container } from 'tsyringe'
import { AirtableAppointmentAdapter } from '../adapter/persist/airtable/adapter/appointment'
import { AirtableCustomerAdapter } from '../adapter/persist/airtable/adapter/customer'
import { AirtableLocationAdapter } from '../adapter/persist/airtable/adapter/location'
import { AirtableOrganizationAdapter } from '../adapter/persist/airtable/adapter/organization'
import { AirtablePeriodAdapter } from '../adapter/persist/airtable/adapter/period'
import { AirtableScheduleAdapter } from '../adapter/persist/airtable/adapter/schedule'
import { AirtableServiceAdapter } from '../adapter/persist/airtable/adapter/service'

container.register<IOrganizationPersist>('OrganizationPersist', AirtableOrganizationAdapter)
container.register<IPeriodPersist>('PeriodPersist', AirtablePeriodAdapter)
container.register<IServicePersist>('ServicePersist', AirtableServiceAdapter)
container.register<ILocationPersist>('LocationPersist', AirtableLocationAdapter)
container.register<ISchedulePersist>('SchedulePersist', AirtableScheduleAdapter)
container.register<IAppointmentPersist>('AppointmentPersist', AirtableAppointmentAdapter)
container.register<ICustomerPersist>('CustomerPersist', AirtableCustomerAdapter)
container.register<IAppointmentPaymentPersist>('AppointmentPaymentPersist', AirtableAppointmentPaymentAdapter)
