import { IServicePersist } from '@/core/persist/service'
import { ServiceSearch } from '@/application/service/search'
import { container } from 'tsyringe'
import { mock, when, instance, verifyAll } from 'strong-mock'
import { MockServiceDTO } from '@test/mock/core/persist/dto'

test('Debe devolver lista de servicios por organización', async () => {
  const organizationId = 'recW5p0rNsxWpUn6w'
  const serviceMock = MockServiceDTO()

  const persist = mock<IServicePersist>()
  when(persist.search(organizationId)).thenResolve([serviceMock])

  const scope = container.createChildContainer()
  scope.registerInstance('ServicePersist', instance(persist))

  const application = scope.resolve(ServiceSearch)
  const items = await application.execute({ organizationId })

  expect(items.length).toEqual(1)
  expect(items[0].id).toEqual(serviceMock.id)
  verifyAll()
})
