import { Request, Response, NextFunction } from 'express'

export const RequestUtils = {
  getBaseUrlFromRequest (req: Request) {
    const context = req.apiGateway.event.requestContext
    let domain = context.domainName
    let protocol = 'https'

    if (domain === 'offlineContext_domainName') {
      protocol = 'http'
      domain = 'localhost:3000'
    }

    const baseUrl = `${protocol}://${domain}/${context.stage}`
    return baseUrl
  }
}

export function handler (asyncHandler: (req: Request, res: Response) => Promise<void>) {
  return (req: Request, res: Response, next: NextFunction) => {
    asyncHandler(req, res).catch(next)
  }
}
