import { z } from 'zod'

export const ScheduleDay = z.enum([
  'lun',
  'mar',
  'mie',
  'jue',
  'vie',
  'sab',
  'dom'
])

export const ScheduleResponse = z.object({
  id: z.string(),
  fields: z.object({
    period: z.array(z.string()).min(1),
    date_start: z.string(),
    date_end: z.string(),
    day: z.array(ScheduleDay),
    slots: z.number()
  }),
  createdTime: z.string()
})

export const ScheduleCollectionResponse = z.object({
  records: z.array(ScheduleResponse)
})
