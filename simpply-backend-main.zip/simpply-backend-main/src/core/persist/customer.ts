export interface ICustomerDTO {
  id: string
  documentType: string
  document: string
  firstName: string
  lastName: string
  email: string
  phone?: string
  birthdate?: string
  address?: string
}

export interface ICustomerSearchByDocumentBulkInput {
  items: Array<{
    document: string
    documentType: string
  }>
}

export interface ICustomerCreateInput {
  items: Array<{
    documentType: string
    document: string
    firstName: string
    lastName: string
    email: string
    phone?: string
    birthdate?: string
    address?: string
  }>
}

export interface ICustomerPersist {
  findById: (id: string) => Promise<ICustomerDTO>
  createBulk: (data: ICustomerCreateInput) => Promise<string[]>
  searchByDocumentBulk: (data: ICustomerSearchByDocumentBulkInput) => Promise<ICustomerDTO[]>
  searchByAppointmentId: (appointmentId: string) => Promise<ICustomerDTO[]>
}
