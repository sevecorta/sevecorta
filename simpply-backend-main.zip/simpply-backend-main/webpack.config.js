const path = require('path')
const slsw = require('serverless-webpack')
const TerserPlugin = require('terser-webpack-plugin')

Object.keys(slsw.lib.entries).forEach((key) => {
  slsw.lib.entries[key] = [
    'reflect-metadata',
    'source-map-support/register',
    './src/infrastructure/container',
    slsw.lib.entries[key]
  ]
})

module.exports = {
  context: __dirname,
  mode: slsw.lib.webpack.isLocal ? 'development' : 'production',
  entry: slsw.lib.entries,
  devtool: slsw.lib.webpack.isLocal ? 'cheap-source-map' : 'source-map',
  ignoreWarnings: [/critical dependency:/i],
  resolve: {
    extensions: ['.ts', '.js'],
    alias: {
      '@': path.resolve(__dirname, 'src')
    }
  },
  target: 'node',
  module: {
    rules: [
      {
        test: /\.ts$/,
        loader: 'ts-loader'
      },
      {
        test: /\.gql$/,
        type: 'asset/source'
      }
    ]
  },
  stats: 'minimal',
  optimization: {
    minimizer: [
      new TerserPlugin({
        terserOptions: {
          mangle: false
        }
      })
    ]
  }
}
