import { z } from 'zod'

export const AppointmentResponse = z.object({
  id: z.string(),
  fields: z.object({
    amount: z.number(),
    date: z.string(),
    service: z.array(z.string()).min(1),
    organization: z.array(z.string()).min(1),
    customer: z.array(z.string()).min(1),
    location: z.array(z.string()).min(1),
    period: z.array(z.string()).min(1)
  }),
  createdTime: z.string()
})

export const AppointmentCollectionResponse = z.object({
  records: z.array(AppointmentResponse)
})
