import organizations from "./organizations.json";

const getOrganization = () => {
    let subdomain = window.location.hostname;

    if (subdomain.includes('.simpp.ly')) {
        subdomain = subdomain.substring(0, subdomain.indexOf('.simpp.ly'));
    } else {
        subdomain = 'dev';
    }
    return organizations.find(org => org.domain == subdomain);
}

export {getOrganization}