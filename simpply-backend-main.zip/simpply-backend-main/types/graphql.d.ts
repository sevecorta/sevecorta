declare module '*.gql' {
  const content: string
  export default content
}
