import { container } from 'tsyringe'
import { IAppointmentPersist } from '@/core/persist/appointment'
import { MockCustomerDTO } from '@test/mock/core/persist/dto'
import { ICustomerPersist } from '@/core/persist/customer'
import { AppointmentCreate } from '@/application/appointment/create'
import { mock, when, instance, It, verifyAll } from 'strong-mock'
import { IUniqueID } from '@/core/ports/unique-id'

test('Debe crear cita reutilizando registros de cliente y paciente', async () => {
  const uniqueid = container.resolve<IUniqueID>('UniqueID')

  const customerMock = MockCustomerDTO({
    documentType: 'RUT',
    document: '11111111'
  })
  const patientMock = MockCustomerDTO({
    documentType: 'RUT',
    document: '22222222'
  })

  const appointmentPersist = mock<IAppointmentPersist>()
  const customerPersist = mock<ICustomerPersist>()
  const appointmentId = uniqueid.generate()

  when(customerPersist.searchByDocumentBulk(
    It.isObject({
      items: [{ document: customerMock.document }]
    })
  )).thenResolve([customerMock])

  when(customerPersist.searchByDocumentBulk(
    It.isObject({
      items: [{ document: patientMock.document }]
    })
  )).thenResolve([patientMock])

  when(appointmentPersist.create(It.isObject({
    customerId: customerMock.id,
    patientsId: [patientMock.id]
  }))).thenResolve(appointmentId)

  const scope = container.createChildContainer()
  scope.registerInstance('AppointmentPersist', instance(appointmentPersist))
  scope.registerInstance('CustomerPersist', instance(customerPersist))

  const application = scope.resolve(AppointmentCreate)
  const itemId = await application.execute({
    date: '2021-06-01',
    amount: 1000,
    organizationId: 'recW5p0rNsxWpUn6w',
    serviceId: 'rec3QhexlBAzfVnBl',
    scheduleId: 'recNxeg9vJAGxhojy',
    periodId: 'recBPCJjHzuh5Cx2H',
    locationId: 'recBPCJjHzuh5Cx2x',
    customer: {
      firstName: 'firstName',
      lastName: 'lastName',
      document: customerMock.document,
      documentType: customerMock.documentType,
      email: 'prueba@email.com'
    },
    patients: [{
      firstName: 'firstName',
      lastName: 'lastName',
      document: patientMock.document,
      documentType: patientMock.documentType,
      email: 'email',
      phone: '9999999',
      address: 'address',
      birthdate: '2021-01-01'
    }]
  })

  expect(itemId).toEqual(appointmentId)
  verifyAll()
})

test('Debe crear cita creando nuevo cliente y reutilizando paciente', async () => {
  const uniqueid = container.resolve<IUniqueID>('UniqueID')

  const customerMock = MockCustomerDTO({
    documentType: 'RUT',
    document: '11111111'
  })
  const patientMock = MockCustomerDTO({
    documentType: 'RUT',
    document: '22222222'
  })

  const appointmentPersist = mock<IAppointmentPersist>()
  const customerPersist = mock<ICustomerPersist>()
  const appointmentId = uniqueid.generate()

  when(customerPersist.searchByDocumentBulk(
    It.isObject({
      items: [{ document: customerMock.document }]
    })
  )).thenResolve([])

  when(customerPersist.searchByDocumentBulk(
    It.isObject({
      items: [{ document: patientMock.document }]
    })
  )).thenResolve([patientMock])

  when(customerPersist.createBulk(
    It.isObject({
      items: [{ document: customerMock.document }]
    })
  )).thenResolve([customerMock.id])

  when(appointmentPersist.create(
    It.isObject({
      customerId: customerMock.id,
      patientsId: [patientMock.id]
    })
  )).thenResolve(appointmentId)

  const scope = container.createChildContainer()
  scope.registerInstance('AppointmentPersist', instance(appointmentPersist))
  scope.registerInstance('CustomerPersist', instance(customerPersist))

  const application = scope.resolve(AppointmentCreate)
  const itemId = await application.execute({
    date: '2021-06-01',
    amount: 1000,
    organizationId: 'recW5p0rNsxWpUn6w',
    serviceId: 'rec3QhexlBAzfVnBl',
    scheduleId: 'recNxeg9vJAGxhojy',
    periodId: 'recBPCJjHzuh5Cx2H',
    locationId: 'recBPCJjHzuh5Cx2x',
    customer: {
      firstName: 'firstName',
      lastName: 'lastName',
      document: customerMock.document,
      documentType: customerMock.documentType,
      email: 'prueba@email.com'
    },
    patients: [{
      firstName: 'firstName',
      lastName: 'lastName',
      document: patientMock.document,
      documentType: patientMock.documentType,
      email: 'email',
      phone: '9999999',
      address: 'address',
      birthdate: '2021-01-01'
    }]
  })

  expect(itemId).toEqual(appointmentId)
  verifyAll()
})

test('Debe crear cita reutilizando cliente y creando nuevo paciente', async () => {
  const uniqueid = container.resolve<IUniqueID>('UniqueID')

  const customerMock = MockCustomerDTO({
    documentType: 'RUT',
    document: '11111111'
  })
  const patientMock = MockCustomerDTO({
    documentType: 'RUT',
    document: '22222222'
  })

  const appointmentPersist = mock<IAppointmentPersist>()
  const customerPersist = mock<ICustomerPersist>()
  const appointmentId = uniqueid.generate()

  when(customerPersist.searchByDocumentBulk(
    It.isObject({
      items: [{ document: customerMock.document }]
    })
  )).thenResolve([customerMock])

  when(customerPersist.searchByDocumentBulk(
    It.isObject({
      items: [{ document: patientMock.document }]
    })
  )).thenResolve([])

  when(customerPersist.createBulk(
    It.isObject({
      items: [{ document: patientMock.document }]
    })
  )).thenResolve([patientMock.id])

  when(appointmentPersist.create(
    It.isObject({
      customerId: customerMock.id,
      patientsId: [patientMock.id]
    })
  )).thenResolve(appointmentId)

  const scope = container.createChildContainer()
  scope.registerInstance('AppointmentPersist', instance(appointmentPersist))
  scope.registerInstance('CustomerPersist', instance(customerPersist))

  const application = scope.resolve(AppointmentCreate)
  const itemId = await application.execute({
    date: '2021-06-01',
    amount: 1000,
    organizationId: 'recW5p0rNsxWpUn6w',
    serviceId: 'rec3QhexlBAzfVnBl',
    scheduleId: 'recNxeg9vJAGxhojy',
    periodId: 'recBPCJjHzuh5Cx2H',
    locationId: 'recBPCJjHzuh5Cx2x',
    customer: {
      firstName: 'firstName',
      lastName: 'lastName',
      document: customerMock.document,
      documentType: customerMock.documentType,
      email: 'prueba@email.com'
    },
    patients: [{
      firstName: 'firstName',
      lastName: 'lastName',
      document: patientMock.document,
      documentType: patientMock.documentType,
      email: 'email',
      phone: '9999999',
      address: 'address',
      birthdate: '2021-01-01'
    }]
  })

  expect(itemId).toEqual(appointmentId)
  verifyAll()
})
