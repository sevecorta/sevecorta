import { mergeTypeDefs } from '@graphql-tools/merge'
import appointment from './schema/appointment.gql'
import calendar from './schema/calendar.gql'
import customer from './schema/customer.gql'
import global from './schema/global.gql'
import location from './schema/location.gql'
import organization from './schema/organization.gql'
import payment from './schema/payment.gql'
import period from './schema/period.gql'
import service from './schema/service.gql'

export const typeDefs = mergeTypeDefs(
  [
    global,
    organization,
    service,
    period,
    appointment,
    calendar,
    location,
    customer,
    payment
  ],
  { sort: true }
)
