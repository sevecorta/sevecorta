export interface IPaymentGatewayCreateInput {
  subject: string
  currency: string
  amount: number
  email: string
  order: string
  urlConfirmation: string
  urlReturn: string
}

export interface IPaymentGatewayCreateOutput {
  token: string
  url: string
  order: string
}

export interface IPaymentGateway {
  create: (params: IPaymentGatewayCreateInput) => Promise<IPaymentGatewayCreateOutput>
  isPaidByToken: (token: string) => Promise<boolean>
}
