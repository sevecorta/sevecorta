import { IAppointmentPersist } from '@/core/persist/appointment'
import { ICustomerPersist } from '@/core/persist/customer'
import { inject, injectable } from 'tsyringe'
import { z } from 'zod'

const Request = z.object({
  date: z.string(),
  amount: z.number(),
  organizationId: z.string().min(1),
  serviceId: z.string().min(1),
  scheduleId: z.string().min(1),
  periodId: z.string().min(1),
  locationId: z.string().min(1),
  customer: z.object({
    firstName: z.string().min(1),
    lastName: z.string().min(1),
    document: z.string().min(1),
    documentType: z.string().min(1),
    email: z.string().email()
  }),
  patients: z.array(z.object({
    firstName: z.string().min(1),
    lastName: z.string().min(1),
    document: z.string().min(1),
    documentType: z.string().min(1),
    email: z.string().min(1),
    phone: z.string().min(1),
    address: z.string().min(1),
    birthdate: z.string().min(1)
  }))
})

@injectable()
export class AppointmentCreate {
  constructor (
    @inject('CustomerPersist')
    private readonly customerPersist: ICustomerPersist,

    @inject('AppointmentPersist')
    private readonly appointmentPersist: IAppointmentPersist
  ) {}

  async execute (dirty: z.infer<typeof Request>): Promise<string> {
    const data = Request.parse(dirty)

    const patientsId = await this.patientSearchOrCreate(data.patients)
    const customerId = await this.customerFindOrCreate(data.customer)

    const appointmentId = await this.appointmentPersist.create({
      organizationId: data.organizationId,
      serviceId: data.serviceId,
      scheduleId: data.scheduleId,
      periodId: data.periodId,
      locationId: data.locationId,
      customerId: customerId,
      date: data.date,
      amount: data.amount,
      patientsId: patientsId
    })

    return appointmentId
  }

  async patientSearchOrCreate (patients: z.infer<typeof Request>['patients']): Promise<string[]> {
    const patientsId = []
    const existingPatients = await this.customerPersist.searchByDocumentBulk(
      {
        items: patients.map((p) => ({
          document: p.document,
          documentType: p.documentType
        }))
      }
    )

    const patientsToCreate = []
    for (const p of patients) {
      let exists = false
      for (const ep of existingPatients) {
        if (p.document === ep.document && p.documentType === ep.documentType) {
          patientsId.push(ep.id)
          exists = true
          break
        }
      }
      if (!exists) {
        patientsToCreate.push(p)
      }
    }

    if (patientsToCreate.length > 0) {
      const newPatients = await this.customerPersist.createBulk({
        items: patientsToCreate
      })
      for (const newPatientId of newPatients) {
        patientsId.push(newPatientId)
      }
    }

    return patientsId
  }

  async customerFindOrCreate (data: z.infer<typeof Request>['customer']): Promise<string> {
    const findCustomer = await this.customerPersist.searchByDocumentBulk({
      items: [{ document: data.document, documentType: data.documentType }]
    })

    if (findCustomer.length > 0) {
      return findCustomer[0].id
    }

    const ids = await this.customerPersist.createBulk({ items: [data] })
    return ids[0]
  }
}
