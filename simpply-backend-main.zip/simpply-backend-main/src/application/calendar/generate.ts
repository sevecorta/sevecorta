import { IAppointmentPersist, IAppointmentGroupByDateDTO } from '@/core/persist/appointment'
import { ISchedulePersist, IScheduleDTO, ScheduleDay } from '@/core/persist/schedule'
import { inject, injectable } from 'tsyringe'
import { Config } from '@/core/config'
import { ILogger } from '@/core/ports/logger'
import { IDateUtil, IDateUtilAction } from '@/core/ports/date-util'
import { IPeriodDTO, IPeriodPersist } from '@/core/persist/period'

interface Request {
  organizationId: string
  year: number
  month: number
}

interface Response
  extends Array<{
    scheduleId: string
    date: string
    periods: Array<{
      periodId: string
      slots: number
    }>
  }> {}

@injectable()
export class CalendarGenerate {
  constructor (
    @inject('SchedulePersist')
    private readonly schedulePersist: ISchedulePersist,

    @inject('PeriodPersist')
    private readonly periodPersist: IPeriodPersist,

    @inject('AppointmentPersist')
    private readonly appointmentPersist: IAppointmentPersist,

    @inject('Logger')
    private readonly logger: ILogger,

    @inject('DateUtil')
    private readonly dateUtil: IDateUtil
  ) {}

  async execute (data: Request): Promise<Response> {
    this.logger.debug('data', data)

    const schedules = await this.schedulePersist.search(data.organizationId)
    const periods = await this.periodPersist.search(data.organizationId)
    const appointmentsByDate = await this.appointmentPersist.groupByDate(
      data.organizationId,
      data.year,
      data.month
    )

    const WeekdayISO: Record<ScheduleDay, number> = {
      lun: 1,
      mar: 2,
      mie: 3,
      jue: 4,
      vie: 5,
      sab: 6,
      dom: 7
    }

    const dateCurrent = this.dateUtil.now().tz(Config.timezone).startOf('day')

    const dateMonthStart = this.dateUtil
      .now()
      .tz(Config.timezone)
      .year(data.year)
      .month(data.month - 1)
      .startOf('month')

    const calendarDateEnd = dateMonthStart.endOf('month')

    this.logger.debug('dateCurrent', dateCurrent.format())
    this.logger.debug('dateMonthStart', dateMonthStart.format())

    if (dateCurrent > calendarDateEnd) {
      return []
    }

    let calendarDateStart = dateMonthStart.clone()
    if (dateCurrent > dateMonthStart && dateCurrent < calendarDateEnd) {
      calendarDateStart = dateCurrent.clone()
    }

    this.logger.debug('calendarDateStart', calendarDateStart.format())
    this.logger.debug('calendarDateEnd', calendarDateEnd.format())

    const dates = []
    for (const schedule of schedules) {
      this.logger.debug('schedule', schedule)

      const daysAllowed = schedule.day.map((dayname) => WeekdayISO[dayname])
      const scheduleDateStart = this.dateUtil
        .tz(schedule.dateStart, Config.timezone)
        .startOf('day')

      const scheduleDateEnd = this.dateUtil
        .tz(schedule.dateEnd, Config.timezone)
        .endOf('day')

      let dateLoopCurrent = scheduleDateStart.clone()
      let dateLoopEnd = scheduleDateEnd.clone()

      if (calendarDateStart > scheduleDateStart) {
        dateLoopCurrent = calendarDateStart.clone()
      }

      if (calendarDateEnd < scheduleDateEnd) {
        dateLoopEnd = calendarDateEnd.clone()
      }

      this.logger.debug('dateLoopCurrent', dateLoopCurrent.format())
      this.logger.debug('dateLoopEnd', dateLoopEnd.format())

      while (dateLoopCurrent <= dateLoopEnd) {
        const dayAllowed = daysAllowed.includes(dateLoopCurrent.isoWeekday())

        if (dayAllowed) {
          dates.push({
            scheduleId: schedule.id,
            date: dateLoopCurrent.format('YYYY-MM-DD'),
            periods: this.getSlotsByPeriod(
              schedule,
              periods,
              dateLoopCurrent,
              appointmentsByDate
            )
          })
        }

        dateLoopCurrent = dateLoopCurrent.add(1, 'day')
      }
    }

    return dates
  }

  getSlotsByPeriod (schedule: IScheduleDTO, periods: IPeriodDTO[], currentDate: IDateUtilAction, appointmentsByDate: IAppointmentGroupByDateDTO[]): Array<{ periodId: string, slots: number }> {
    const items = []

    for (const period of periods) {
      if (schedule.periodId !== period.id) {
        continue
      }

      let slots = schedule.slots
      for (const groupByDate of appointmentsByDate) {
        const isSchedule = groupByDate.scheduleId.includes(schedule.id)
        const isPeriod = groupByDate.periodId.includes(period.id)
        const isDate = groupByDate.date === currentDate.format('YYYY-MM-DD')
        const isMatch = isSchedule && isPeriod && isDate
        if (isMatch) {
          slots -= groupByDate.count
          break
        }
      }

      items.push({
        periodId: period.id,
        slots: slots
      })
    }

    return items
  }
}
