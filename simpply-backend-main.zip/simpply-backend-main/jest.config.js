const { jsWithTs: tsjPreset } = require('ts-jest/presets')
const { pathsToModuleNameMapper } = require('ts-jest/utils')
const { compilerOptions } = require('./tsconfig')

process.env.STAGE = 'test'

module.exports = {
  testEnvironment: 'node',
  transform: {
    ...tsjPreset.transform,
    '^.+\\.gql$': [
      '<rootDir>/test/jest.transform.js',
      {
        supportsDynamicImport: true
      }
    ]
  },
  moduleNameMapper: pathsToModuleNameMapper(compilerOptions.paths, {
    prefix: __dirname
  }),
  roots: ['./test'],
  setupFiles: ['./test/setup.ts'],
  collectCoverageFrom: [
    './src/**'
  ]
}
