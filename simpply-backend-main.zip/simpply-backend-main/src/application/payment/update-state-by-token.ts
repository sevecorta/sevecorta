import { ILogger } from '@/core/ports/logger'
import { IAppointmentPaymentPersist } from '@/core/persist/appointment-payment'
import { inject, injectable } from 'tsyringe'
import { IPaymentGateway } from '@/core/ports/payment-gateway'

interface Request {
  token: string
}

@injectable()
export class PaymentUpdateStateByToken {
  constructor (
    @inject('AppointmentPaymentPersist')
    private readonly appointmentPaymentPersist: IAppointmentPaymentPersist,

    @inject('PaymentGateway')
    private readonly paymentGateway: IPaymentGateway,

    @inject('Logger')
    private readonly logger: ILogger
  ) {}

  async execute (data: Request): Promise<void> {
    this.logger.debug('data', data)

    const isPaid = await this.paymentGateway.isPaidByToken(data.token)
    const payment = await this.appointmentPaymentPersist.findByToken(data.token)

    const state = isPaid ? 'success' : 'error'
    await this.appointmentPaymentPersist.updateState(payment.id, state)
  }
}
