import { IOrganizationPersist, IOrganizationDTO } from '@/core/persist/organization'
import { inject, injectable } from 'tsyringe'

interface Request {
  id: string
}

@injectable()
export class OrganizationFindById {
  constructor (
    @inject('OrganizationPersist')
    private readonly persist: IOrganizationPersist
  ) {}

  async execute (data: Request): Promise<IOrganizationDTO> {
    const item = await this.persist.findById(data.id)
    return item
  }
}
