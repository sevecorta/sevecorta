export interface IAppointmentDTO {
  id: string
  date: string
  amount: number
  serviceId: string
  organizationId: string
  customerId: string
  locationId: string
  periodId: string
  createdTime: string
}

export interface IAppointmentGroupByDateDTO {
  scheduleId: string
  periodId: string
  date: string
  count: number
}

export interface IAppointmentCreateInput {
  organizationId: string
  serviceId: string
  scheduleId: string
  periodId: string
  customerId: string
  locationId: string
  date: string
  amount: number
  patientsId: string[]
}

export interface IAppointmentPersist {
  create: (params: IAppointmentCreateInput) => Promise<string>
  findById: (id: string) => Promise<IAppointmentDTO>
  groupByDate: (organizationId: string, year: number, month: number) => Promise<IAppointmentGroupByDateDTO[]>
}
