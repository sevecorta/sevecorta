import { container } from 'tsyringe'
import { mock, when, instance, verifyAll } from 'strong-mock'
import { MockOrganizationDTO } from '@test/mock/core/persist/dto'
import { IOrganizationPersist } from '@/core/persist/organization'
import { OrganizationSearch } from '@/application/organization/search'

test('Debe devolver lista de organizaciones', async () => {
  const organizationMock = MockOrganizationDTO()

  const persist = mock<IOrganizationPersist>()
  when(persist.search()).thenResolve([organizationMock])

  const scope = container.createChildContainer()
  scope.registerInstance('OrganizationPersist', instance(persist))

  const application = scope.resolve(OrganizationSearch)
  const items = await application.execute()

  expect(items.length).toEqual(1)
  expect(items[0].id).toEqual(organizationMock.id)
  verifyAll()
})
