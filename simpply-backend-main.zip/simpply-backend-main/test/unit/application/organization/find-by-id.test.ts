import { container } from 'tsyringe'
import { mock, when, instance, verifyAll } from 'strong-mock'
import { MockOrganizationDTO } from '@test/mock/core/persist/dto'
import { IOrganizationPersist } from '@/core/persist/organization'
import { OrganizationFindById } from '@/application/organization/find-by-id'

test('Debe devolver organización por id', async () => {
  const organizationMock = MockOrganizationDTO()

  const persist = mock<IOrganizationPersist>()
  when(persist.findById(organizationMock.id)).thenResolve(organizationMock)

  const scope = container.createChildContainer()
  scope.registerInstance('OrganizationPersist', instance(persist))

  const application = scope.resolve(OrganizationFindById)
  const item = await application.execute({ id: organizationMock.id })

  expect(item.id).toEqual(organizationMock.id)
  verifyAll()
})
