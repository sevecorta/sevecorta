import { AppointmentCreate } from '@/application/appointment/create'
import { AppointmentFindById } from '@/application/appointment/find-by-id'
import { CalendarGenerate } from '@/application/calendar/generate'
import { CustomerFindById } from '@/application/customer/find-by-id'
import { LocationSearch } from '@/application/location/search'
import { OrganizationFindById } from '@/application/organization/find-by-id'
import { OrganizationSearch } from '@/application/organization/search'
import { PaymentCreate } from '@/application/payment/create'
import { PaymentFindById } from '@/application/payment/find-by-id'
import { PeriodSearch } from '@/application/period/search'
import { ServiceFindById } from '@/application/service/find-by-id'
import { ServiceSearch } from '@/application/service/search'
import { RequestUtils } from '../helper/request'
import { PathUtils } from '../helper/path'
import { IContext } from './context'
import { LocationFindById } from '@/application/location/find-by-id'
import { PeriodFindById } from '@/application/period/find-by-id'
import { PaymentSearchByAppointmentId } from '@/application/payment/search-by-appointment-id'
import { CustomerSearchByAppointmentId } from '@/application/customer/search-by-appointment-id'

export const resolver = {
  Query: {
    organizations: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(OrganizationSearch)
      return await instance.execute()
    },
    services: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(ServiceSearch)
      return await instance.execute(args.search)
    },
    periods: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(PeriodSearch)
      return await instance.execute(args.search)
    },
    locations: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(LocationSearch)
      return await instance.execute(args.search)
    },
    appointment: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(AppointmentFindById)
      return await instance.execute({ id: args.id })
    },
    calendar: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(CalendarGenerate)
      return await instance.execute(args.search)
    }
  },
  Mutation: {
    appointmentCreate: async (obj: any, args: any, ctx: IContext) => {
      const create = ctx.request.container.resolve(AppointmentCreate)
      const findById = ctx.request.container.resolve(AppointmentFindById)
      const appointmentId = await create.execute(args.input)
      return await findById.execute({ id: appointmentId })
    },
    paymentCreate: async (obj: any, args: any, ctx: IContext) => {
      const requestBaseUrl = RequestUtils.getBaseUrlFromRequest(ctx.request)
      const create = ctx.request.container.resolve(PaymentCreate)
      const findById = ctx.request.container.resolve(PaymentFindById)
      const paymentId = await create.execute({
        ...args.input,
        urlConfirmation: PathUtils.getPaymentUrlConfirmation(requestBaseUrl),
        urlReturn: PathUtils.getPaymentUrlReturn(
          requestBaseUrl,
          args.input.appointmentId
        )
      })
      return await findById.execute({ id: paymentId })
    }
  },
  Appointment: {
    service: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(ServiceFindById)
      return await instance.execute({ id: obj.serviceId })
    },
    organization: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(OrganizationFindById)
      return await instance.execute({ id: obj.organizationId })
    },
    customer: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(CustomerFindById)
      return await instance.execute({ id: obj.customerId })
    },
    location: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(LocationFindById)
      return await instance.execute({ id: obj.locationId })
    },
    period: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(PeriodFindById)
      return await instance.execute({ id: obj.periodId })
    },
    payments: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(PaymentSearchByAppointmentId)
      return await instance.execute({ appointmentId: obj.id })
    },
    patients: async (obj: any, args: any, ctx: IContext) => {
      const instance = ctx.request.container.resolve(CustomerSearchByAppointmentId)
      return await instance.execute({ appointmentId: obj.id })
    }
  },
  CalendarPeriod: {
    period: async (obj: any, args: any, ctx: IContext) => {
      return await ctx.loader.periodLoader.load(obj.periodId)
    }
  }
}
