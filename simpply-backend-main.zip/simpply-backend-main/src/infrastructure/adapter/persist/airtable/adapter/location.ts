import { ILocationPersist, ILocationDTO } from '@/core/persist/location'
import { AirtableClient } from '../client'
import { LocationCollectionResponse, LocationResponse } from '../schema/location'

export class AirtableLocationAdapter implements ILocationPersist {
  async search (organizationId: string): Promise<ILocationDTO[]> {
    const formula = `FIND('${organizationId}', {organization__record_id}) > 0`
    const resp = await AirtableClient.get('location', {
      params: { view: 'backend', filterByFormula: formula }
    })
    const data = LocationCollectionResponse.parse(resp.data)

    return data.records.map((obj) => ({
      id: obj.id,
      name: obj.fields.name,
      amount: obj.fields.amount
    }))
  }

  async findById (id: string): Promise<ILocationDTO> {
    const resp = await AirtableClient.get(`organization/${id}`)
    const data = LocationResponse.parse(resp.data)

    return {
      id: data.id,
      name: data.fields.name,
      amount: data.fields.amount
    }
  }
}
