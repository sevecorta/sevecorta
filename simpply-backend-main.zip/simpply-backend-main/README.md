# SIMPPLY-BACKEND

[![JavaScript Style Guide](https://cdn.rawgit.com/standard/standard/master/badge.svg)](https://github.com/standard/standard)


## Requerimientos
- Node 12
- Npm 6

### Tareas principales

Instala dependencias del proyecto
```
./run.sh install
```

Ejecutar servidor en modo local
```
./run.sh server
```

Compilar proyecto con webpack
```
./run.sh build
```

Ejecutar pruebas
```
./run.sh test
```

Ejecutar pruebas de un solo archivo
```
./run.sh test test/example.test.ts
```

Ejecutar pruebas de un solo archivo y un solo test
```
./run.sh test test/example.test.ts -t 'nombre del test'
```

Publicar proyecto
```
./run.sh deploy
```

Otros scripts de utilidad se encuentran en el directorio **tools**.


### Variables de entorno
Por defecto se carga el archivo **.env.local**
