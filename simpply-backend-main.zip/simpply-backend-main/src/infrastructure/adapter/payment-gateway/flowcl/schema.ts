import { z } from 'zod'

export const PaymentCreateResponse = z.object({
  token: z.string(),
  url: z.string(),
  flowOrder: z.number()
})

export const PaymentStatusResponse = z.object({
  status: z.number()
})
