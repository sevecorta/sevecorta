import { IDateUtil } from '@/core/ports/date-util'
import { ILogger } from '@/core/ports/logger'
import { IUniqueID } from '@/core/ports/unique-id'
import { DayjsDateUtilAdapter } from '@/infrastructure/adapter/date-util/dayjs'
import { LoggerAdapter } from '@/infrastructure/adapter/logger/tslog'
import { UniqueIDAdapter } from '@/infrastructure/adapter/unique-id/short-uuid'
import { container } from 'tsyringe'

container.register<ILogger>('Logger', LoggerAdapter)
container.register<IDateUtil>('DateUtil', DayjsDateUtilAdapter)
container.register<IUniqueID>('UniqueID', UniqueIDAdapter)
