import axios from 'axios'
import { AirtableConfig } from './config'

const baseUrl = `https://api.airtable.com/v0/${AirtableConfig.baseId}/`

export const AirtableClient = axios.create({
  baseURL: baseUrl,
  timeout: AirtableConfig.apiTimeout,
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${AirtableConfig.apiKey}`
  }
})
