export type ScheduleDay = 'lun' | 'mar' | 'mie' | 'jue' | 'vie' | 'sab' | 'dom'

export interface IScheduleDTO {
  id: string
  dateStart: string
  dateEnd: string
  periodId: string
  day: ScheduleDay[]
  slots: number
}

export interface ISchedulePersist {
  search: (organizationId: string) => Promise<IScheduleDTO[]>
}
